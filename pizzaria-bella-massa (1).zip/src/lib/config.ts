export const STORE = {
  name: "Bella Massa Pizzaria",
  slogan: "A pizza mais amada da cidade, quentinha na sua porta.",
  // Número do WhatsApp da empresa (somente dígitos, com DDI). Pode ser sobrescrito por env.
  whatsapp: process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || "5511999999999",
  // Localização da pizzaria (ponto de partida das rotas dos entregadores)
  lat: Number(process.env.NEXT_PUBLIC_STORE_LAT || -23.55052),
  lng: Number(process.env.NEXT_PUBLIC_STORE_LNG || -46.633308),
  address: "Av. Paulista, 1000 - São Paulo, SP",
  deliveryFee: 6,
};

export const DEFAULT_ADMIN = {
  name: "Administrador",
  email: "admin@bellamassa.com",
  password: "J4590n23@",
};

export const ORDER_STATUS_LABEL: Record<string, string> = {
  pendente: "Aguardando confirmação",
  confirmado: "Confirmado",
  em_rota: "Em rota de entrega",
  entregue: "Entregue",
  cancelado: "Cancelado",
};
