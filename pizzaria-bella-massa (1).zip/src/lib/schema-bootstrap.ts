import { sql } from "drizzle-orm";
import { db } from "@/db";

let ready: Promise<void> | null = null;

/**
 * Cria as tabelas automaticamente caso ainda não existam (idempotente).
 * Permite fazer o deploy em Vercel + Neon sem rodar `drizzle-kit push` manualmente.
 * As definições espelham `src/db/schema.ts`.
 */
export function ensureSchema(): Promise<void> {
  if (ready) return ready;
  ready = (async () => {
    await db.execute(sql`
      CREATE TABLE IF NOT EXISTS admins (
        id serial PRIMARY KEY,
        name text NOT NULL,
        email text NOT NULL UNIQUE,
        password_hash text NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS deliverers (
        id serial PRIMARY KEY,
        name text NOT NULL,
        phone text NOT NULL UNIQUE,
        vehicle text NOT NULL DEFAULT 'Moto',
        password_hash text NOT NULL,
        active boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS sessions (
        id serial PRIMARY KEY,
        token text NOT NULL UNIQUE,
        role text NOT NULL,
        user_id integer NOT NULL,
        expires_at timestamptz NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS products (
        id serial PRIMARY KEY,
        name text NOT NULL,
        description text NOT NULL DEFAULT '',
        category text NOT NULL DEFAULT 'Pizzas',
        price numeric(10,2) NOT NULL,
        emoji text NOT NULL DEFAULT '🍕',
        image_url text,
        available boolean NOT NULL DEFAULT true,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS orders (
        id serial PRIMARY KEY,
        customer_name text NOT NULL,
        customer_phone text NOT NULL,
        address text NOT NULL,
        complement text NOT NULL DEFAULT '',
        lat double precision,
        lng double precision,
        items jsonb NOT NULL,
        total numeric(10,2) NOT NULL,
        notes text NOT NULL DEFAULT '',
        payment_method text NOT NULL DEFAULT 'Pix',
        status text NOT NULL DEFAULT 'pendente',
        location_confirmed boolean NOT NULL DEFAULT false,
        deliverer_id integer,
        created_at timestamptz NOT NULL DEFAULT now(),
        updated_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS images (
        id serial PRIMARY KEY,
        mime text NOT NULL,
        data text NOT NULL,
        size integer NOT NULL,
        created_at timestamptz NOT NULL DEFAULT now()
      );
      CREATE TABLE IF NOT EXISTS settings (
        key text PRIMARY KEY,
        value text NOT NULL,
        updated_at timestamptz NOT NULL DEFAULT now()
      );
    `);
  })().catch((err) => {
    ready = null; // permite tentar de novo na próxima requisição
    throw err;
  });
  return ready;
}
