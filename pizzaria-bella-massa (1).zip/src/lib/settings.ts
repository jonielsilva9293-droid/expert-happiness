import { db } from "@/db";
import { settings } from "@/db/schema";
import { STORE } from "@/lib/config";

export type StoreSettings = {
  whatsapp: string; // somente dígitos, com DDI (ex.: 5511999999999)
  storeName: string;
  storeAddress: string;
  storeLat: number;
  storeLng: number;
  deliveryFee: number;
  minOrder: number;
  isOpen: boolean;
};

const DEFAULTS: StoreSettings = {
  whatsapp: STORE.whatsapp,
  storeName: STORE.name,
  storeAddress: STORE.address,
  storeLat: STORE.lat,
  storeLng: STORE.lng,
  deliveryFee: STORE.deliveryFee,
  minOrder: 0,
  isOpen: true,
};

export function normalizePhone(raw: string): string {
  let digits = String(raw || "").replace(/\D/g, "");
  // Se não tiver DDI e parecer um número brasileiro (DDD + 8/9 dígitos), adiciona 55
  if (digits.length === 10 || digits.length === 11) digits = `55${digits}`;
  return digits;
}

export async function getSettings(): Promise<StoreSettings> {
  try {
    const rows = await db.select().from(settings);
    const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
    return {
      whatsapp: map.whatsapp || DEFAULTS.whatsapp,
      storeName: map.storeName || DEFAULTS.storeName,
      storeAddress: map.storeAddress || DEFAULTS.storeAddress,
      storeLat: map.storeLat !== undefined ? Number(map.storeLat) : DEFAULTS.storeLat,
      storeLng: map.storeLng !== undefined ? Number(map.storeLng) : DEFAULTS.storeLng,
      deliveryFee: map.deliveryFee !== undefined ? Number(map.deliveryFee) : DEFAULTS.deliveryFee,
      minOrder: map.minOrder !== undefined ? Number(map.minOrder) : DEFAULTS.minOrder,
      isOpen: map.isOpen !== undefined ? map.isOpen === "true" : DEFAULTS.isOpen,
    };
  } catch {
    return DEFAULTS;
  }
}

export async function saveSettings(partial: Partial<StoreSettings>): Promise<StoreSettings> {
  const entries = Object.entries(partial).filter(([, v]) => v !== undefined) as [string, unknown][];
  for (const [key, value] of entries) {
    await db
      .insert(settings)
      .values({ key, value: String(value), updatedAt: new Date() })
      .onConflictDoUpdate({ target: settings.key, set: { value: String(value), updatedAt: new Date() } });
  }
  return getSettings();
}
