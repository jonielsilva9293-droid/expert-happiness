import { and, eq, isNull } from "drizzle-orm";
import { db } from "@/db";
import { admins, products } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { DEFAULT_ADMIN } from "@/lib/config";
import { ensureSchema } from "@/lib/schema-bootstrap";

let seeded = false;

const IMG = "/images/products";

const SEED_PRODUCTS = [
  { name: "Margherita", description: "Molho de tomate, mussarela, manjericão fresco e azeite.", price: "42.90", category: "Pizzas Tradicionais", emoji: "🍕", imageUrl: `${IMG}/margherita.jpg` },
  { name: "Calabresa", description: "Calabresa fatiada, cebola roxa, azeitonas e orégano.", price: "45.90", category: "Pizzas Tradicionais", emoji: "🍕", imageUrl: `${IMG}/calabresa.jpg` },
  { name: "Portuguesa", description: "Presunto, ovos, cebola, ervilha, azeitona e mussarela.", price: "49.90", category: "Pizzas Tradicionais", emoji: "🍕", imageUrl: `${IMG}/portuguesa.jpg` },
  { name: "Quatro Queijos", description: "Mussarela, provolone, parmesão e gorgonzola.", price: "52.90", category: "Pizzas Especiais", emoji: "🧀", imageUrl: `${IMG}/quatro-queijos.jpg` },
  { name: "Frango com Catupiry", description: "Frango desfiado, catupiry cremoso e milho.", price: "48.90", category: "Pizzas Especiais", emoji: "🍗", imageUrl: `${IMG}/frango-catupiry.jpg` },
  { name: "Pepperoni", description: "Pepperoni artesanal, mussarela e molho especial.", price: "54.90", category: "Pizzas Especiais", emoji: "🌶️", imageUrl: `${IMG}/pepperoni.jpg` },
  { name: "Chocolate com Morango", description: "Chocolate ao leite, morangos frescos e leite condensado.", price: "39.90", category: "Pizzas Doces", emoji: "🍫", imageUrl: `${IMG}/chocolate-morango.jpg` },
  { name: "Banana com Canela", description: "Banana, canela, açúcar e leite condensado.", price: "36.90", category: "Pizzas Doces", emoji: "🍌", imageUrl: `${IMG}/banana-canela.jpg` },
  { name: "Coca-Cola 2L", description: "Refrigerante gelado 2 litros.", price: "12.00", category: "Bebidas", emoji: "🥤", imageUrl: `${IMG}/refrigerante.jpg` },
  { name: "Guaraná 2L", description: "Refrigerante gelado 2 litros.", price: "10.00", category: "Bebidas", emoji: "🥤", imageUrl: `${IMG}/refrigerante.jpg` },
  { name: "Suco Natural 500ml", description: "Laranja, limão ou maracujá.", price: "9.00", category: "Bebidas", emoji: "🧃", imageUrl: `${IMG}/suco.jpg` },
];

export async function ensureSeed() {
  if (seeded) return;
  try {
    await ensureSchema();
    const existingAdmins = await db.select({ id: admins.id }).from(admins).limit(1);
    if (existingAdmins.length === 0) {
      await db.insert(admins).values({
        name: DEFAULT_ADMIN.name,
        email: DEFAULT_ADMIN.email,
        passwordHash: hashPassword(DEFAULT_ADMIN.password),
      });
    }

    const existingProducts = await db.select({ id: products.id }).from(products).limit(1);
    if (existingProducts.length === 0) {
      await db.insert(products).values(SEED_PRODUCTS);
    } else {
      // Preenche imagens de demonstração em produtos padrão que ainda não têm imagem
      for (const p of SEED_PRODUCTS) {
        await db
          .update(products)
          .set({ imageUrl: p.imageUrl })
          .where(and(eq(products.name, p.name), isNull(products.imageUrl)));
      }
    }
    seeded = true;
  } catch (err) {
    console.error("Seed error", err);
  }
}
