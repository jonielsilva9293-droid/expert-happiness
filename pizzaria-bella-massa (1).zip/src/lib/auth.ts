import { cookies } from "next/headers";
import { randomBytes, scryptSync, timingSafeEqual } from "crypto";
import { and, eq, gt } from "drizzle-orm";
import { db } from "@/db";
import { admins, deliverers, sessions } from "@/db/schema";

export const SESSION_COOKIE = "bm_session";
const SESSION_DAYS = 7;

export function hashPassword(password: string): string {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string): boolean {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const derived = scryptSync(password, salt, 64);
  const expected = Buffer.from(hash, "hex");
  if (derived.length !== expected.length) return false;
  return timingSafeEqual(derived, expected);
}

export type SessionRole = "admin" | "deliverer";

export type SessionUser = {
  role: SessionRole;
  id: number;
  name: string;
  identifier: string;
};

export async function createSession(role: SessionRole, userId: number) {
  const token = randomBytes(32).toString("hex");
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 24 * 60 * 60 * 1000);
  await db.insert(sessions).values({ token, role, userId, expiresAt });
  const cookieStore = await cookies();
  cookieStore.set(SESSION_COOKIE, token, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    expires: expiresAt,
  });
  return token;
}

export async function destroySession() {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (token) {
    await db.delete(sessions).where(eq(sessions.token, token));
  }
  cookieStore.delete(SESSION_COOKIE);
}

export async function getSessionUser(): Promise<SessionUser | null> {
  const cookieStore = await cookies();
  const token = cookieStore.get(SESSION_COOKIE)?.value;
  if (!token) return null;

  const [session] = await db
    .select()
    .from(sessions)
    .where(and(eq(sessions.token, token), gt(sessions.expiresAt, new Date())))
    .limit(1);
  if (!session) return null;

  if (session.role === "admin") {
    const [admin] = await db.select().from(admins).where(eq(admins.id, session.userId)).limit(1);
    if (!admin) return null;
    return { role: "admin", id: admin.id, name: admin.name, identifier: admin.email };
  }

  const [deliverer] = await db
    .select()
    .from(deliverers)
    .where(eq(deliverers.id, session.userId))
    .limit(1);
  if (!deliverer || !deliverer.active) return null;
  return { role: "deliverer", id: deliverer.id, name: deliverer.name, identifier: deliverer.phone };
}

export async function requireRole(role: SessionRole) {
  const user = await getSessionUser();
  if (!user || user.role !== role) return null;
  return user;
}

export function unauthorized(message = "Não autorizado") {
  return Response.json({ error: message }, { status: 401 });
}
