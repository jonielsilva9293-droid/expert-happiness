export type GeoPoint = { lat: number; lng: number };

const EARTH_RADIUS_KM = 6371;

export function haversineKm(a: GeoPoint, b: GeoPoint): number {
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLng = toRad(b.lng - a.lng);
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const h =
    Math.sin(dLat / 2) ** 2 + Math.cos(lat1) * Math.cos(lat2) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.sqrt(h));
}

/**
 * Otimização de rota pelo algoritmo do vizinho mais próximo, seguido de
 * melhoria 2-opt. Começa no ponto de partida (pizzaria) e sempre vai ao
 * ponto de entrega mais perto do último visitado.
 */
export function optimizeRoute<T extends GeoPoint>(start: GeoPoint, stops: T[]) {
  if (stops.length === 0) return { ordered: [] as T[], legsKm: [] as number[], totalKm: 0 };

  const remaining = [...stops];
  const ordered: T[] = [];
  let current: GeoPoint = start;

  while (remaining.length > 0) {
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0; i < remaining.length; i++) {
      const d = haversineKm(current, remaining[i]);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    const [next] = remaining.splice(bestIdx, 1);
    ordered.push(next);
    current = next;
  }

  // Melhoria 2-opt
  let improved = true;
  const routeLength = (route: T[]) => {
    let total = 0;
    let prev: GeoPoint = start;
    for (const p of route) {
      total += haversineKm(prev, p);
      prev = p;
    }
    return total;
  };
  let best = ordered;
  let bestLen = routeLength(best);
  while (improved && best.length > 3) {
    improved = false;
    for (let i = 0; i < best.length - 1; i++) {
      for (let k = i + 1; k < best.length; k++) {
        const candidate = [
          ...best.slice(0, i),
          ...best.slice(i, k + 1).reverse(),
          ...best.slice(k + 1),
        ];
        const len = routeLength(candidate);
        if (len < bestLen - 1e-9) {
          best = candidate;
          bestLen = len;
          improved = true;
        }
      }
    }
  }

  const legsKm: number[] = [];
  let prev: GeoPoint = start;
  for (const p of best) {
    legsKm.push(haversineKm(prev, p));
    prev = p;
  }
  return { ordered: best, legsKm, totalKm: bestLen };
}

export function wazeUrl(p: GeoPoint) {
  return `https://waze.com/ul?ll=${p.lat},${p.lng}&navigate=yes`;
}

export function googleMapsUrl(p: GeoPoint) {
  return `https://www.google.com/maps/dir/?api=1&destination=${p.lat},${p.lng}&travelmode=driving`;
}

export function googleMapsMultiStopUrl(start: GeoPoint, stops: GeoPoint[]) {
  if (stops.length === 0) return googleMapsUrl(start);
  const last = stops[stops.length - 1];
  const waypoints = stops
    .slice(0, -1)
    .map((s) => `${s.lat},${s.lng}`)
    .join("|");
  const base = `https://www.google.com/maps/dir/?api=1&origin=${start.lat},${start.lng}&destination=${last.lat},${last.lng}&travelmode=driving`;
  return waypoints ? `${base}&waypoints=${encodeURIComponent(waypoints)}` : base;
}
