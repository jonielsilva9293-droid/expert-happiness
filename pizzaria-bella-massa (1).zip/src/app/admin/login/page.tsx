import { redirect } from "next/navigation";
import LoginForm from "@/components/LoginForm";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  const user = await getSessionUser();
  if (user?.role === "admin") redirect("/admin");

  return (
    <LoginForm
      role="admin"
      title="Área Administrativa"
      subtitle="Gerencie pedidos, produtos, entregadores e administradores."
      identifierLabel="E-mail"
      identifierPlaceholder="admin@bellamassa.com"
      redirectTo="/admin"
      icon="🛡️"
    />
  );
}
