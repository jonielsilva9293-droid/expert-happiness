import StoreFront from "@/components/StoreFront";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <StoreFront />;
}
