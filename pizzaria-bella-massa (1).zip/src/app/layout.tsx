import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Bella Massa Pizzaria — Delivery",
  description:
    "Pizzas artesanais com entrega rápida. Peça pelo site e finalize no WhatsApp.",
};

export const viewport: Viewport = {
  themeColor: "#d62828",
  width: "device-width",
  initialScale: 1,
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="pt-BR">
      <body className="min-h-screen bg-[#fff7ed] text-stone-900 antialiased">{children}</body>
    </html>
  );
}
