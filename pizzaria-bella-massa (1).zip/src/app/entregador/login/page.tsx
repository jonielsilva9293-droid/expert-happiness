import { redirect } from "next/navigation";
import LoginForm from "@/components/LoginForm";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function DelivererLoginPage() {
  const user = await getSessionUser();
  if (user?.role === "deliverer") redirect("/entregador");

  return (
    <LoginForm
      role="deliverer"
      title="Área do Entregador"
      subtitle="Veja suas entregas e a rota otimizada."
      identifierLabel="Telefone"
      identifierPlaceholder="11999999999"
      redirectTo="/entregador"
      icon="🛵"
    />
  );
}
