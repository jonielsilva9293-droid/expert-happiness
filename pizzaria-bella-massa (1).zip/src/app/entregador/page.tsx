import { redirect } from "next/navigation";
import DelivererPanel from "@/components/deliverer/DelivererPanel";
import { getSessionUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function DelivererPage() {
  const user = await getSessionUser();
  if (!user || user.role !== "deliverer") redirect("/entregador/login");
  return <DelivererPanel user={{ id: user.id, name: user.name }} />;
}
