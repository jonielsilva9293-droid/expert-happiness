import { requireRole, unauthorized } from "@/lib/auth";
import { getSettings, normalizePhone, saveSettings } from "@/lib/settings";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  await ensureSeed();
  const s = await getSettings();
  return Response.json({ settings: s });
}

export async function PUT(req: Request) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();

  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "Dados inválidos." }, { status: 400 });

  const update: Record<string, unknown> = {};

  if (body.whatsapp !== undefined) {
    const phone = normalizePhone(body.whatsapp);
    if (phone.length < 10 || phone.length > 15) {
      return Response.json(
        { error: "Número de WhatsApp inválido. Use DDD + número, ex.: (11) 99999-9999." },
        { status: 400 }
      );
    }
    update.whatsapp = phone;
  }
  if (typeof body.storeName === "string" && body.storeName.trim()) update.storeName = body.storeName.trim();
  if (typeof body.storeAddress === "string") update.storeAddress = body.storeAddress.trim();
  if (body.storeLat !== undefined && body.storeLng !== undefined) {
    const lat = Number(body.storeLat);
    const lng = Number(body.storeLng);
    if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
      return Response.json({ error: "Coordenadas da pizzaria inválidas." }, { status: 400 });
    }
    update.storeLat = lat;
    update.storeLng = lng;
  }
  if (body.deliveryFee !== undefined) {
    const fee = Number(body.deliveryFee);
    if (!Number.isFinite(fee) || fee < 0) return Response.json({ error: "Taxa de entrega inválida." }, { status: 400 });
    update.deliveryFee = fee;
  }
  if (body.minOrder !== undefined) {
    const min = Number(body.minOrder);
    if (!Number.isFinite(min) || min < 0) return Response.json({ error: "Pedido mínimo inválido." }, { status: 400 });
    update.minOrder = min;
  }
  if (typeof body.isOpen === "boolean") update.isOpen = body.isOpen;

  const saved = await saveSettings(update);
  return Response.json({ settings: saved });
}
