import { eq } from "drizzle-orm";
import { db } from "@/db";
import { admins, deliverers } from "@/db/schema";
import { createSession, verifyPassword } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function POST(req: Request) {
  await ensureSeed();
  const body = await req.json().catch(() => null);
  const role = body?.role as "admin" | "deliverer" | undefined;
  const identifier = String(body?.identifier || "").trim().toLowerCase();
  const password = String(body?.password || "");

  if (!role || !identifier || !password) {
    return Response.json({ error: "Preencha todos os campos." }, { status: 400 });
  }

  if (role === "admin") {
    const [admin] = await db.select().from(admins).where(eq(admins.email, identifier)).limit(1);
    if (!admin || !verifyPassword(password, admin.passwordHash)) {
      return Response.json({ error: "E-mail ou senha inválidos." }, { status: 401 });
    }
    await createSession("admin", admin.id);
    return Response.json({ ok: true, user: { role: "admin", id: admin.id, name: admin.name } });
  }

  const phone = identifier.replace(/\D/g, "");
  const [deliverer] = await db
    .select()
    .from(deliverers)
    .where(eq(deliverers.phone, phone))
    .limit(1);
  if (!deliverer || !verifyPassword(password, deliverer.passwordHash)) {
    return Response.json({ error: "Telefone ou senha inválidos." }, { status: 401 });
  }
  if (!deliverer.active) {
    return Response.json({ error: "Entregador desativado. Fale com o administrador." }, { status: 403 });
  }
  await createSession("deliverer", deliverer.id);
  return Response.json({
    ok: true,
    user: { role: "deliverer", id: deliverer.id, name: deliverer.name },
  });
}
