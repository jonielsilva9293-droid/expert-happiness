export const dynamic = "force-dynamic";

const HEADERS = {
  "User-Agent": "BellaMassaPizzaria/1.0 (contato@bellamassa.com)",
  "Accept-Language": "pt-BR",
};

export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q");
  const lat = searchParams.get("lat");
  const lng = searchParams.get("lng");

  try {
    if (lat && lng) {
      const url = `https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${encodeURIComponent(lat)}&lon=${encodeURIComponent(lng)}`;
      const res = await fetch(url, { headers: HEADERS, cache: "no-store" });
      if (!res.ok) throw new Error("reverse failed");
      const data = await res.json();
      return Response.json({ address: data.display_name || "" });
    }

    if (q) {
      const url = `https://nominatim.openstreetmap.org/search?format=jsonv2&limit=1&countrycodes=br&q=${encodeURIComponent(q)}`;
      const res = await fetch(url, { headers: HEADERS, cache: "no-store" });
      if (!res.ok) throw new Error("search failed");
      const data = (await res.json()) as Array<{ lat: string; lon: string; display_name: string }>;
      if (!data.length) return Response.json({ result: null });
      return Response.json({
        result: { lat: Number(data[0].lat), lng: Number(data[0].lon), address: data[0].display_name },
      });
    }

    return Response.json({ error: "Informe q ou lat/lng." }, { status: 400 });
  } catch {
    return Response.json({ error: "Serviço de geolocalização indisponível." }, { status: 502 });
  }
}
