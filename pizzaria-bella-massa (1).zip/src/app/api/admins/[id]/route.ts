import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { admins, sessions } from "@/db/schema";
import { requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function DELETE(_req: Request, { params }: Ctx) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const { id } = await params;
  const adminId = Number(id);
  if (!Number.isInteger(adminId)) return Response.json({ error: "ID inválido." }, { status: 400 });
  if (adminId === admin.id) {
    return Response.json({ error: "Você não pode excluir a si mesmo." }, { status: 400 });
  }
  const count = await db.select({ id: admins.id }).from(admins);
  if (count.length <= 1) {
    return Response.json({ error: "É necessário manter ao menos um administrador." }, { status: 400 });
  }
  await db.delete(sessions).where(and(eq(sessions.userId, adminId), eq(sessions.role, "admin")));
  await db.delete(admins).where(eq(admins.id, adminId));
  return Response.json({ ok: true });
}
