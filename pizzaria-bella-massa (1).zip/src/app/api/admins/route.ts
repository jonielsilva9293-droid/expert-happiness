import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { admins } from "@/db/schema";
import { hashPassword, requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

export async function GET() {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const list = await db
    .select({ id: admins.id, name: admins.name, email: admins.email, createdAt: admins.createdAt })
    .from(admins)
    .orderBy(asc(admins.id));
  return Response.json({ admins: list });
}

export async function POST(req: Request) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();

  const body = await req.json().catch(() => null);
  const name = String(body?.name || "").trim();
  const email = String(body?.email || "").trim().toLowerCase();
  const password = String(body?.password || "");

  if (!name || !email || password.length < 6) {
    return Response.json(
      { error: "Nome, e-mail e senha (mín. 6 caracteres) são obrigatórios." },
      { status: 400 }
    );
  }

  const [exists] = await db.select({ id: admins.id }).from(admins).where(eq(admins.email, email)).limit(1);
  if (exists) return Response.json({ error: "Já existe um administrador com este e-mail." }, { status: 409 });

  const [created] = await db
    .insert(admins)
    .values({ name, email, passwordHash: hashPassword(password) })
    .returning({ id: admins.id, name: admins.name, email: admins.email, createdAt: admins.createdAt });
  return Response.json({ admin: created }, { status: 201 });
}
