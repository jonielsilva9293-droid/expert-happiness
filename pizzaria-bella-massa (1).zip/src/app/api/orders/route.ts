import { and, desc, eq, inArray } from "drizzle-orm";
import { db } from "@/db";
import { orders, products, type OrderItem } from "@/db/schema";
import { getSessionUser, unauthorized } from "@/lib/auth";
import { googleMapsMultiStopUrl, optimizeRoute } from "@/lib/route";
import { getSettings } from "@/lib/settings";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  if (user.role === "admin") {
    const list = await db.select().from(orders).orderBy(desc(orders.createdAt));
    return Response.json({ orders: list });
  }

  // Entregador: pedidos atribuídos a ele que ainda não foram entregues
  const mine = await db
    .select()
    .from(orders)
    .where(
      and(eq(orders.delivererId, user.id), inArray(orders.status, ["confirmado", "em_rota"]))
    )
    .orderBy(desc(orders.createdAt));

  type MineOrder = (typeof mine)[number];
  const withCoords = mine.filter((o) => o.lat !== null && o.lng !== null) as Array<
    MineOrder & { lat: number; lng: number }
  >;
  const withoutCoords = mine.filter((o) => o.lat === null || o.lng === null);

  const cfg = await getSettings();
  const start = { lat: cfg.storeLat, lng: cfg.storeLng };
  const { ordered, legsKm, totalKm } = optimizeRoute(start, withCoords);

  const route = ordered.map((o, idx) => ({
    ...o,
    sequence: idx + 1,
    legKm: Number(legsKm[idx].toFixed(2)),
  }));

  const delivered = await db
    .select()
    .from(orders)
    .where(and(eq(orders.delivererId, user.id), eq(orders.status, "entregue")))
    .orderBy(desc(orders.updatedAt))
    .limit(20);

  return Response.json({
    start,
    storeName: cfg.storeName,
    route,
    unlocated: withoutCoords,
    totalKm: Number(totalKm.toFixed(2)),
    googleMapsRouteUrl: googleMapsMultiStopUrl(start, ordered),
    delivered,
  });
}

export async function POST(req: Request) {
  await ensureSeed();
  const body = await req.json().catch(() => null);
  if (!body) return Response.json({ error: "Dados inválidos." }, { status: 400 });

  const customerName = String(body.customerName || "").trim();
  const customerPhone = String(body.customerPhone || "").replace(/\D/g, "");
  const address = String(body.address || "").trim();
  const complement = String(body.complement || "").trim();
  const notes = String(body.notes || "").trim();
  const paymentMethod = String(body.paymentMethod || "Pix").trim();
  const lat = body.lat !== null && body.lat !== undefined ? Number(body.lat) : null;
  const lng = body.lng !== null && body.lng !== undefined ? Number(body.lng) : null;
  const rawItems = Array.isArray(body.items) ? body.items : [];

  if (!customerName || !customerPhone || !address) {
    return Response.json({ error: "Nome, telefone e endereço são obrigatórios." }, { status: 400 });
  }
  if (rawItems.length === 0) {
    return Response.json({ error: "Seu carrinho está vazio." }, { status: 400 });
  }

  const ids = rawItems.map((i: { productId: number }) => Number(i.productId)).filter(Number.isInteger);
  const dbProducts = ids.length
    ? await db.select().from(products).where(and(inArray(products.id, ids), eq(products.available, true)))
    : [];

  const items: OrderItem[] = [];
  for (const raw of rawItems) {
    const product = dbProducts.find((p) => p.id === Number(raw.productId));
    const quantity = Math.max(1, Math.min(50, Number(raw.quantity) || 1));
    if (!product) continue;
    items.push({ productId: product.id, name: product.name, price: Number(product.price), quantity });
  }
  if (items.length === 0) {
    return Response.json({ error: "Os produtos selecionados não estão mais disponíveis." }, { status: 400 });
  }

  const cfg = await getSettings();
  if (!cfg.isOpen) {
    return Response.json({ error: "A pizzaria está fechada no momento. Volte mais tarde! 🍕" }, { status: 400 });
  }
  if (!cfg.whatsapp) {
    return Response.json({ error: "WhatsApp da loja não configurado. Avise o administrador." }, { status: 500 });
  }

  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  if (cfg.minOrder > 0 && subtotal < cfg.minOrder) {
    return Response.json(
      { error: `Pedido mínimo de R$ ${cfg.minOrder.toFixed(2)} (sem a taxa de entrega).` },
      { status: 400 }
    );
  }
  const total = subtotal + cfg.deliveryFee;

  const [created] = await db
    .insert(orders)
    .values({
      customerName,
      customerPhone,
      address,
      complement,
      notes,
      paymentMethod,
      lat: Number.isFinite(lat as number) ? lat : null,
      lng: Number.isFinite(lng as number) ? lng : null,
      items,
      total: total.toFixed(2),
      status: "pendente",
    })
    .returning();

  const lines = items.map((i) => `• ${i.quantity}x ${i.name} — R$ ${(i.price * i.quantity).toFixed(2)}`);
  const mapsLink =
    created.lat !== null && created.lng !== null
      ? `https://www.google.com/maps?q=${created.lat},${created.lng}`
      : "Não informada";
  const message = [
    `🍕 *Novo pedido #${created.id} - ${cfg.storeName}*`,
    ``,
    `👤 *Cliente:* ${customerName}`,
    `📞 *Telefone:* ${customerPhone}`,
    ``,
    `🛒 *Itens:*`,
    ...lines,
    ``,
    `🚚 Taxa de entrega: R$ ${cfg.deliveryFee.toFixed(2)}`,
    `💰 *Total: R$ ${total.toFixed(2)}*`,
    `💳 Pagamento: ${paymentMethod}`,
    ``,
    `📍 *Endereço:* ${address}${complement ? ` (${complement})` : ""}`,
    `🗺️ Localização: ${mapsLink}`,
    notes ? `📝 Obs: ${notes}` : "",
    ``,
    `Aguardo a confirmação do pedido! 😊`,
  ]
    .filter((l) => l !== undefined)
    .join("\n");

  // Redireciona o cliente para o WhatsApp da empresa configurado pelo ADM
  const whatsappUrl = `https://wa.me/${cfg.whatsapp}?text=${encodeURIComponent(message)}`;

  return Response.json({ order: created, whatsappUrl }, { status: 201 });
}
