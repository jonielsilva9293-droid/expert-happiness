import { eq } from "drizzle-orm";
import { db } from "@/db";
import { orders } from "@/db/schema";
import { getSessionUser, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

const ADMIN_ACTIONS = ["confirmar", "atribuir", "em_rota", "entregue", "cancelar", "reabrir"] as const;
const DELIVERER_ACTIONS = ["em_rota", "entregue"] as const;

export async function PATCH(req: Request, { params }: Ctx) {
  const user = await getSessionUser();
  if (!user) return unauthorized();

  const { id } = await params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) return Response.json({ error: "ID inválido." }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const action = String(body.action || "");

  const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
  if (!order) return Response.json({ error: "Pedido não encontrado." }, { status: 404 });

  const update: Partial<typeof orders.$inferInsert> = { updatedAt: new Date() };

  if (user.role === "admin") {
    if (!ADMIN_ACTIONS.includes(action as (typeof ADMIN_ACTIONS)[number])) {
      return Response.json({ error: "Ação inválida." }, { status: 400 });
    }
    switch (action) {
      case "confirmar":
        // Ao confirmar a venda, a localização do cliente é confirmada automaticamente
        update.status = "confirmado";
        update.locationConfirmed = order.lat !== null && order.lng !== null;
        if (body.delivererId !== undefined && body.delivererId !== null && body.delivererId !== "") {
          update.delivererId = Number(body.delivererId);
        }
        break;
      case "atribuir":
        update.delivererId = body.delivererId ? Number(body.delivererId) : null;
        if (order.status === "pendente") {
          update.status = "confirmado";
          update.locationConfirmed = order.lat !== null && order.lng !== null;
        }
        break;
      case "em_rota":
        update.status = "em_rota";
        break;
      case "entregue":
        update.status = "entregue";
        break;
      case "cancelar":
        update.status = "cancelado";
        break;
      case "reabrir":
        update.status = "pendente";
        update.locationConfirmed = false;
        update.delivererId = null;
        break;
    }
  } else {
    if (order.delivererId !== user.id) return unauthorized("Este pedido não está atribuído a você.");
    if (!DELIVERER_ACTIONS.includes(action as (typeof DELIVERER_ACTIONS)[number])) {
      return Response.json({ error: "Ação inválida." }, { status: 400 });
    }
    update.status = action === "em_rota" ? "em_rota" : "entregue";
  }

  const [updated] = await db.update(orders).set(update).where(eq(orders.id, orderId)).returning();
  return Response.json({ order: updated });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const user = await getSessionUser();
  if (!user || user.role !== "admin") return unauthorized();
  const { id } = await params;
  const orderId = Number(id);
  if (!Number.isInteger(orderId)) return Response.json({ error: "ID inválido." }, { status: 400 });
  await db.delete(orders).where(eq(orders.id, orderId));
  return Response.json({ ok: true });
}
