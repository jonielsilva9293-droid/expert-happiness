import { db } from "@/db";
import { images } from "@/db/schema";
import { requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

const MAX_BYTES = 4 * 1024 * 1024; // 4 MB
const ALLOWED = ["image/jpeg", "image/png", "image/webp", "image/gif"];

export async function POST(req: Request) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();

  const form = await req.formData().catch(() => null);
  const file = form?.get("file");
  if (!file || !(file instanceof File)) {
    return Response.json({ error: "Nenhum arquivo enviado." }, { status: 400 });
  }
  if (!ALLOWED.includes(file.type)) {
    return Response.json({ error: "Formato inválido. Use JPG, PNG, WEBP ou GIF." }, { status: 400 });
  }
  if (file.size > MAX_BYTES) {
    return Response.json({ error: "Imagem muito grande (máx. 4 MB)." }, { status: 400 });
  }

  const buffer = Buffer.from(await file.arrayBuffer());
  const [created] = await db
    .insert(images)
    .values({ mime: file.type, data: buffer.toString("base64"), size: buffer.length })
    .returning({ id: images.id });

  return Response.json({ url: `/api/images/${created.id}`, id: created.id }, { status: 201 });
}
