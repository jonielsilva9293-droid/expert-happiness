import { eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const { id } = await params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) {
    return Response.json({ error: "ID inválido." }, { status: 400 });
  }

  const body = await req.json().catch(() => ({}));
  const update: Partial<typeof products.$inferInsert> = {};
  if (typeof body.available === "boolean") update.available = body.available;
  if (typeof body.name === "string" && body.name.trim()) update.name = body.name.trim();
  if (typeof body.description === "string") update.description = body.description.trim();
  if (typeof body.category === "string" && body.category.trim()) update.category = body.category.trim();
  if (typeof body.emoji === "string" && body.emoji.trim()) update.emoji = body.emoji.trim();
  if (body.imageUrl !== undefined) {
    update.imageUrl = body.imageUrl ? String(body.imageUrl).trim() : null;
  }
  if (body.price !== undefined) {
    const price = Number(body.price);
    if (!Number.isFinite(price) || price <= 0) {
      return Response.json({ error: "Preço inválido." }, { status: 400 });
    }
    update.price = price.toFixed(2);
  }

  const [updated] = await db.update(products).set(update).where(eq(products.id, productId)).returning();
  if (!updated) return Response.json({ error: "Produto não encontrado." }, { status: 404 });
  return Response.json({ product: updated });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const { id } = await params;
  const productId = Number(id);
  if (!Number.isInteger(productId)) {
    return Response.json({ error: "ID inválido." }, { status: 400 });
  }
  const deleted = await db.delete(products).where(eq(products.id, productId)).returning();
  if (deleted.length === 0) return Response.json({ error: "Produto não encontrado." }, { status: 404 });
  return Response.json({ ok: true });
}
