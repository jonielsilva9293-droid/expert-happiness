import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { products } from "@/db/schema";
import { requireRole, unauthorized } from "@/lib/auth";
import { ensureSeed } from "@/lib/seed";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  await ensureSeed();
  const { searchParams } = new URL(req.url);
  const all = searchParams.get("all") === "1";

  if (all) {
    const admin = await requireRole("admin");
    if (!admin) return unauthorized();
    const list = await db.select().from(products).orderBy(asc(products.category), asc(products.name));
    return Response.json({ products: list });
  }

  const list = await db
    .select()
    .from(products)
    .where(eq(products.available, true))
    .orderBy(asc(products.category), asc(products.name));
  return Response.json({ products: list });
}

export async function POST(req: Request) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();

  const body = await req.json().catch(() => null);
  const name = String(body?.name || "").trim();
  const description = String(body?.description || "").trim();
  const category = String(body?.category || "Pizzas").trim();
  const emoji = String(body?.emoji || "🍕").trim() || "🍕";
  const imageUrl = body?.imageUrl ? String(body.imageUrl).trim() : null;
  const price = Number(body?.price);

  if (!name || !Number.isFinite(price) || price <= 0) {
    return Response.json({ error: "Nome e preço válidos são obrigatórios." }, { status: 400 });
  }

  const [created] = await db
    .insert(products)
    .values({ name, description, category, emoji, imageUrl, price: price.toFixed(2), available: true })
    .returning();
  return Response.json({ product: created }, { status: 201 });
}
