import { eq } from "drizzle-orm";
import { db } from "@/db";
import { images } from "@/db/schema";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function GET(_req: Request, { params }: Ctx) {
  const { id } = await params;
  const imageId = Number(id);
  if (!Number.isInteger(imageId)) return new Response("Not found", { status: 404 });

  const [img] = await db.select().from(images).where(eq(images.id, imageId)).limit(1);
  if (!img) return new Response("Not found", { status: 404 });

  const buffer = Buffer.from(img.data, "base64");
  return new Response(buffer, {
    status: 200,
    headers: {
      "Content-Type": img.mime,
      "Content-Length": String(buffer.length),
      "Cache-Control": "public, max-age=31536000, immutable",
    },
  });
}
