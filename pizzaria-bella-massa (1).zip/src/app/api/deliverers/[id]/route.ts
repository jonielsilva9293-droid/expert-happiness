import { and, eq } from "drizzle-orm";
import { db } from "@/db";
import { deliverers, orders, sessions } from "@/db/schema";
import { hashPassword, requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

type Ctx = { params: Promise<{ id: string }> };

export async function PATCH(req: Request, { params }: Ctx) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const { id } = await params;
  const delivererId = Number(id);
  if (!Number.isInteger(delivererId)) return Response.json({ error: "ID inválido." }, { status: 400 });

  const body = await req.json().catch(() => ({}));
  const update: Partial<typeof deliverers.$inferInsert> = {};
  if (typeof body.active === "boolean") update.active = body.active;
  if (typeof body.name === "string" && body.name.trim()) update.name = body.name.trim();
  if (typeof body.vehicle === "string" && body.vehicle.trim()) update.vehicle = body.vehicle.trim();
  if (typeof body.password === "string" && body.password.length >= 4) {
    update.passwordHash = hashPassword(body.password);
  }

  const [updated] = await db
    .update(deliverers)
    .set(update)
    .where(eq(deliverers.id, delivererId))
    .returning({
      id: deliverers.id,
      name: deliverers.name,
      phone: deliverers.phone,
      vehicle: deliverers.vehicle,
      active: deliverers.active,
      createdAt: deliverers.createdAt,
    });
  if (!updated) return Response.json({ error: "Entregador não encontrado." }, { status: 404 });
  return Response.json({ deliverer: updated });
}

export async function DELETE(_req: Request, { params }: Ctx) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const { id } = await params;
  const delivererId = Number(id);
  if (!Number.isInteger(delivererId)) return Response.json({ error: "ID inválido." }, { status: 400 });

  await db.update(orders).set({ delivererId: null }).where(eq(orders.delivererId, delivererId));
  await db
    .delete(sessions)
    .where(and(eq(sessions.userId, delivererId), eq(sessions.role, "deliverer")));
  await db.delete(deliverers).where(eq(deliverers.id, delivererId));
  return Response.json({ ok: true });
}
