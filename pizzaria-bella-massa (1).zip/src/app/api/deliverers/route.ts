import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { deliverers } from "@/db/schema";
import { hashPassword, requireRole, unauthorized } from "@/lib/auth";

export const dynamic = "force-dynamic";

const publicCols = {
  id: deliverers.id,
  name: deliverers.name,
  phone: deliverers.phone,
  vehicle: deliverers.vehicle,
  active: deliverers.active,
  createdAt: deliverers.createdAt,
};

export async function GET() {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();
  const list = await db.select(publicCols).from(deliverers).orderBy(asc(deliverers.name));
  return Response.json({ deliverers: list });
}

export async function POST(req: Request) {
  const admin = await requireRole("admin");
  if (!admin) return unauthorized();

  const body = await req.json().catch(() => null);
  const name = String(body?.name || "").trim();
  const phone = String(body?.phone || "").replace(/\D/g, "");
  const vehicle = String(body?.vehicle || "Moto").trim() || "Moto";
  const password = String(body?.password || "");

  if (!name || phone.length < 8 || password.length < 4) {
    return Response.json(
      { error: "Nome, telefone válido e senha (mín. 4 caracteres) são obrigatórios." },
      { status: 400 }
    );
  }

  const [exists] = await db
    .select({ id: deliverers.id })
    .from(deliverers)
    .where(eq(deliverers.phone, phone))
    .limit(1);
  if (exists) return Response.json({ error: "Já existe um entregador com este telefone." }, { status: 409 });

  const [created] = await db
    .insert(deliverers)
    .values({ name, phone, vehicle, passwordHash: hashPassword(password) })
    .returning(publicCols);
  return Response.json({ deliverer: created }, { status: 201 });
}
