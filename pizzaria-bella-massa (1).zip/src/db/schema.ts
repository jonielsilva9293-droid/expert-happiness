import {
  pgTable,
  serial,
  text,
  boolean,
  timestamp,
  integer,
  doublePrecision,
  numeric,
  jsonb,
} from "drizzle-orm/pg-core";

export const admins = pgTable("admins", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const deliverers = pgTable("deliverers", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull().unique(),
  vehicle: text("vehicle").default("Moto").notNull(),
  passwordHash: text("password_hash").notNull(),
  active: boolean("active").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const sessions = pgTable("sessions", {
  id: serial("id").primaryKey(),
  token: text("token").notNull().unique(),
  role: text("role").notNull(), // 'admin' | 'deliverer'
  userId: integer("user_id").notNull(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description").default("").notNull(),
  category: text("category").default("Pizzas").notNull(),
  price: numeric("price", { precision: 10, scale: 2 }).notNull(),
  emoji: text("emoji").default("🍕").notNull(),
  imageUrl: text("image_url"),
  available: boolean("available").default(true).notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

export type OrderItem = {
  productId: number;
  name: string;
  price: number;
  quantity: number;
};

export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  customerName: text("customer_name").notNull(),
  customerPhone: text("customer_phone").notNull(),
  address: text("address").notNull(),
  complement: text("complement").default("").notNull(),
  lat: doublePrecision("lat"),
  lng: doublePrecision("lng"),
  items: jsonb("items").$type<OrderItem[]>().notNull(),
  total: numeric("total", { precision: 10, scale: 2 }).notNull(),
  notes: text("notes").default("").notNull(),
  paymentMethod: text("payment_method").default("Pix").notNull(),
  // pendente | confirmado | em_rota | entregue | cancelado
  status: text("status").default("pendente").notNull(),
  locationConfirmed: boolean("location_confirmed").default(false).notNull(),
  delivererId: integer("deliverer_id"),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

// Imagens enviadas pelo ADM (armazenadas em base64 no banco e servidas por /api/images/[id])
export const images = pgTable("images", {
  id: serial("id").primaryKey(),
  mime: text("mime").notNull(),
  data: text("data").notNull(),
  size: integer("size").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow().notNull(),
});

// Configurações da loja editáveis pelo ADM (chave/valor)
export const settings = pgTable("settings", {
  key: text("key").primaryKey(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at", { withTimezone: true }).defaultNow().notNull(),
});

export type Admin = typeof admins.$inferSelect;
export type Deliverer = typeof deliverers.$inferSelect;
export type Product = typeof products.$inferSelect;
export type Order = typeof orders.$inferSelect;
