"use client";

import Link from "next/link";
import { useCallback, useEffect, useMemo, useState } from "react";
import LeafletMap from "@/components/LeafletMap";
import { STORE } from "@/lib/config";

type Product = {
  id: number;
  name: string;
  description: string;
  category: string;
  price: string;
  emoji: string;
  imageUrl: string | null;
};

type CartItem = { product: Product; quantity: number };

type GeoLoc = { lat: number; lng: number } | null;

const brl = (v: number) => v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

/** Formata 5511999999999 → +55 (11) 99999-9999 */
function formatPhone(digits: string): string {
  const d = digits.replace(/\D/g, "");
  const m = d.match(/^55(\d{2})(\d{4,5})(\d{4})$/);
  if (m) return `+55 (${m[1]}) ${m[2]}-${m[3]}`;
  return `+${d}`;
}

export default function StoreFront() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  // Configurações da loja definidas pelo ADM (WhatsApp, taxa, nome, aberto/fechado…)
  const [store, setStore] = useState({
    name: STORE.name,
    address: STORE.address,
    whatsapp: STORE.whatsapp,
    lat: STORE.lat,
    lng: STORE.lng,
    deliveryFee: STORE.deliveryFee,
    minOrder: 0,
    isOpen: true,
  });

  useEffect(() => {
    fetch("/api/settings")
      .then((r) => r.json())
      .then((d) => {
        const s = d.settings;
        if (!s) return;
        setStore({
          name: s.storeName,
          address: s.storeAddress,
          whatsapp: s.whatsapp,
          lat: s.storeLat,
          lng: s.storeLng,
          deliveryFee: s.deliveryFee,
          minOrder: s.minOrder,
          isOpen: s.isOpen,
        });
      })
      .catch(() => {});
  }, []);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkoutOpen, setCheckoutOpen] = useState(false);
  const [activeCategory, setActiveCategory] = useState<string>("Todos");
  const [toast, setToast] = useState<string | null>(null);

  // Localização / checkout
  const [location, setLocation] = useState<GeoLoc>(null);
  const [locating, setLocating] = useState(false);
  const [locError, setLocError] = useState<string | null>(null);
  const [form, setForm] = useState({
    customerName: "",
    customerPhone: "",
    address: "",
    complement: "",
    notes: "",
    paymentMethod: "Pix",
  });
  const [submitting, setSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [success, setSuccess] = useState<{ orderId: number; whatsappUrl: string } | null>(null);

  useEffect(() => {
    fetch("/api/products")
      .then((r) => r.json())
      .then((d) => setProducts(d.products || []))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    try {
      const saved = localStorage.getItem("bm_customer");
      if (saved) {
        const parsed = JSON.parse(saved);
        setForm((f) => ({ ...f, ...parsed.form }));
        if (parsed.location) setLocation(parsed.location);
      }
    } catch {
      /* ignore */
    }
  }, []);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 1800);
    return () => clearTimeout(t);
  }, [toast]);

  const categories = useMemo(
    () => ["Todos", ...Array.from(new Set(products.map((p) => p.category)))],
    [products]
  );
  const visible = useMemo(
    () => (activeCategory === "Todos" ? products : products.filter((p) => p.category === activeCategory)),
    [products, activeCategory]
  );

  const subtotal = cart.reduce((s, i) => s + Number(i.product.price) * i.quantity, 0);
  const total = subtotal + (cart.length ? store.deliveryFee : 0);
  const belowMinimum = store.minOrder > 0 && cart.length > 0 && subtotal < store.minOrder;
  const cartCount = cart.reduce((s, i) => s + i.quantity, 0);

  const addToCart = (product: Product) => {
    setCart((c) => {
      const found = c.find((i) => i.product.id === product.id);
      if (found) return c.map((i) => (i.product.id === product.id ? { ...i, quantity: i.quantity + 1 } : i));
      return [...c, { product, quantity: 1 }];
    });
    setToast(`${product.emoji} ${product.name} adicionado!`);
  };
  const changeQty = (id: number, delta: number) => {
    setCart((c) =>
      c
        .map((i) => (i.product.id === id ? { ...i, quantity: i.quantity + delta } : i))
        .filter((i) => i.quantity > 0)
    );
  };

  const requestCurrentLocation = useCallback(() => {
    if (!navigator.geolocation) {
      setLocError("Seu navegador não suporta geolocalização.");
      return;
    }
    setLocating(true);
    setLocError(null);
    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const loc = { lat: pos.coords.latitude, lng: pos.coords.longitude };
        setLocation(loc);
        try {
          const r = await fetch(`/api/geocode?lat=${loc.lat}&lng=${loc.lng}`);
          const d = await r.json();
          if (d.address) setForm((f) => ({ ...f, address: f.address || d.address }));
        } catch {
          /* ignore */
        }
        setLocating(false);
      },
      () => {
        setLocError("Não conseguimos obter sua localização. Marque no mapa ou digite o endereço.");
        setLocating(false);
      },
      { enableHighAccuracy: true, timeout: 10000 }
    );
  }, []);

  const searchAddress = async () => {
    if (!form.address.trim()) return;
    setLocating(true);
    setLocError(null);
    try {
      const r = await fetch(`/api/geocode?q=${encodeURIComponent(form.address)}`);
      const d = await r.json();
      if (d.result) {
        setLocation({ lat: d.result.lat, lng: d.result.lng });
      } else {
        setLocError("Endereço não encontrado. Toque no mapa para marcar sua localização.");
      }
    } catch {
      setLocError("Não foi possível buscar o endereço.");
    } finally {
      setLocating(false);
    }
  };

  const submitOrder = async () => {
    setSubmitting(true);
    setSubmitError(null);
    try {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          ...form,
          lat: location?.lat ?? null,
          lng: location?.lng ?? null,
          items: cart.map((i) => ({ productId: i.product.id, quantity: i.quantity })),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro ao enviar pedido.");
      localStorage.setItem("bm_customer", JSON.stringify({ form, location }));
      setSuccess({ orderId: data.order.id, whatsappUrl: data.whatsappUrl });
      setCart([]);
      // Redireciona para o WhatsApp da empresa
      window.open(data.whatsappUrl, "_blank", "noopener");
    } catch (e) {
      setSubmitError(e instanceof Error ? e.message : "Erro inesperado.");
    } finally {
      setSubmitting(false);
    }
  };

  const mapMarkers = useMemo(
    () => (location ? [{ id: "me", lat: location.lat, lng: location.lng, label: "🏠", color: "#2f5d3a" }] : []),
    [location]
  );
  const mapCenter = location ?? { lat: store.lat, lng: store.lng };

  return (
    <div className="min-h-screen">
      {/* NAVBAR */}
      <header className="glass sticky top-0 z-40 border-b border-orange-100">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <a href="#" className="flex items-center gap-2">
            <span className="animate-spin-slow text-3xl">🍕</span>
            <span className="text-lg font-black tracking-tight text-red-700">{store.name}</span>
          </a>
          <nav className="hidden items-center gap-6 text-sm font-semibold text-stone-700 md:flex">
            <a href="#cardapio" className="transition hover:text-red-600">Cardápio</a>
            <a href="#como-funciona" className="transition hover:text-red-600">Como funciona</a>
            <Link href="/entregador/login" className="transition hover:text-red-600">Entregadores</Link>
            <Link href="/admin/login" className="transition hover:text-red-600">Admin</Link>
          </nav>
          <button
            onClick={() => setCartOpen(true)}
            className="btn-brand relative flex items-center gap-2 rounded-full px-4 py-2 text-sm font-bold"
          >
            🛒 Carrinho
            {cartCount > 0 && (
              <span
                key={cartCount}
                className="animate-pop absolute -right-2 -top-2 flex h-6 w-6 items-center justify-center rounded-full bg-yellow-400 text-xs font-black text-red-900"
              >
                {cartCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* HERO */}
      <section className="relative overflow-hidden">
        <div className="checker absolute inset-0 opacity-70" />
        <div className="absolute -left-24 -top-24 h-80 w-80 rounded-full bg-red-200/50 blur-3xl" />
        <div className="absolute -bottom-24 -right-24 h-96 w-96 rounded-full bg-yellow-200/60 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <span className="animate-fade-in-up inline-flex items-center gap-2 rounded-full bg-red-100 px-3 py-1 text-xs font-bold uppercase tracking-wider text-red-700">
              <span className="relative flex h-2 w-2">
                {store.isOpen && (
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-green-400 opacity-75" />
                )}
                <span className={`relative inline-flex h-2 w-2 rounded-full ${store.isOpen ? "bg-green-500" : "bg-stone-400"}`} />
              </span>
              {store.isOpen ? "Aberto agora · Entrega em ~40 min" : "Fechado no momento"}
            </span>
            <h1 className="animate-fade-in-up delay-100 mt-4 text-5xl font-black leading-[1.05] tracking-tight text-stone-900 md:text-6xl">
              Pizza de <span className="text-red-600">verdade</span>, do forno à sua porta.
            </h1>
            <p className="animate-fade-in-up delay-200 mt-5 max-w-lg text-lg text-stone-600">{STORE.slogan}</p>
            <div className="animate-fade-in-up delay-300 mt-8 flex flex-wrap gap-3">
              <a href="#cardapio" className="btn-brand rounded-full px-7 py-3 text-base font-bold">
                Ver cardápio
              </a>
              <button
                onClick={() => {
                  setCheckoutOpen(true);
                  requestCurrentLocation();
                }}
                className="rounded-full border-2 border-stone-900 px-7 py-3 text-base font-bold text-stone-900 transition hover:bg-stone-900 hover:text-white"
              >
                📍 Usar minha localização
              </button>
            </div>
            <div className="animate-fade-in-up delay-400 mt-8 flex gap-8 text-sm text-stone-600">
              <div><span className="block text-2xl font-black text-stone-900">4.9★</span>avaliação</div>
              <div><span className="block text-2xl font-black text-stone-900">+12k</span>pizzas entregues</div>
              <div><span className="block text-2xl font-black text-stone-900">{brl(store.deliveryFee)}</span>taxa fixa</div>
            </div>
          </div>
          <div className="relative flex items-center justify-center">
            <div className="relative">
              <div className="absolute left-1/2 top-4 -translate-x-1/2">
                <span className="animate-steam absolute -left-6 block h-10 w-3 rounded-full bg-white/70 blur-sm" />
                <span className="animate-steam absolute left-0 block h-12 w-3 rounded-full bg-white/70 blur-sm [animation-delay:0.7s]" />
                <span className="animate-steam absolute left-6 block h-10 w-3 rounded-full bg-white/70 blur-sm [animation-delay:1.3s]" />
              </div>
              <div className="animate-float flex h-64 w-64 items-center justify-center rounded-full bg-gradient-to-br from-yellow-300 via-orange-400 to-red-500 shadow-2xl shadow-red-300/60 md:h-80 md:w-80">
                <span className="text-[9rem] drop-shadow-2xl md:text-[11rem]">🍕</span>
              </div>
              <div className="animate-pop delay-500 absolute -bottom-3 -left-6 rounded-2xl bg-white px-4 py-3 shadow-xl">
                <p className="text-xs text-stone-500">Mais pedida</p>
                <p className="font-black text-stone-900">Calabresa 🔥</p>
              </div>
              <div className="animate-pop delay-300 absolute -right-4 top-6 rounded-2xl bg-white px-4 py-3 shadow-xl">
                <p className="text-xs text-stone-500">Entrega rastreada</p>
                <p className="font-black text-stone-900">🛵 Em tempo real</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* COMO FUNCIONA */}
      <section id="como-funciona" className="mx-auto max-w-6xl px-4 py-12">
        <div className="grid gap-4 md:grid-cols-4">
          {[
            ["🍕", "Escolha", "Monte seu pedido no cardápio."],
            ["📍", "Localize", "Use sua localização atual ou digite o endereço."],
            ["💬", "Confirme", "Finalize pelo WhatsApp da pizzaria."],
            ["🛵", "Receba", "Nosso entregador vai pela rota mais rápida."],
          ].map(([icon, title, desc], i) => (
            <div
              key={title}
              className={`card-hover animate-fade-in-up rounded-2xl bg-white p-5 shadow-sm delay-${(i + 1) * 100}`}
            >
              <div className="text-3xl">{icon}</div>
              <h3 className="mt-2 font-black text-stone-900">{title}</h3>
              <p className="text-sm text-stone-600">{desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* CARDÁPIO */}
      <section id="cardapio" className="mx-auto max-w-6xl px-4 pb-24">
        <div className="flex flex-wrap items-end justify-between gap-4">
          <div>
            <h2 className="text-3xl font-black tracking-tight text-stone-900 md:text-4xl">Nosso cardápio</h2>
            <p className="text-stone-600">Massa de fermentação lenta, ingredientes frescos todos os dias.</p>
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((c) => (
              <button
                key={c}
                onClick={() => setActiveCategory(c)}
                className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-all ${
                  activeCategory === c
                    ? "bg-red-600 text-white shadow-lg shadow-red-200"
                    : "bg-white text-stone-700 hover:bg-red-50"
                }`}
              >
                {c}
              </button>
            ))}
          </div>
        </div>

        {loading ? (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {Array.from({ length: 6 }).map((_, i) => (
              <div key={i} className="h-56 animate-pulse rounded-3xl bg-white/70" />
            ))}
          </div>
        ) : visible.length === 0 ? (
          <p className="mt-10 text-center text-stone-500">Nenhum produto disponível nesta categoria no momento.</p>
        ) : (
          <div className="mt-8 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {visible.map((p, i) => (
              <article
                key={p.id}
                className="card-hover animate-fade-in-up group relative flex flex-col overflow-hidden rounded-3xl bg-white shadow-sm"
                style={{ animationDelay: `${(i % 6) * 80}ms` }}
              >
                {p.imageUrl ? (
                  <div className="relative h-48 w-full overflow-hidden">
                    {/* eslint-disable-next-line @next/next/no-img-element */}
                    <img
                      src={p.imageUrl}
                      alt={p.name}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent" />
                    <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-xs font-bold text-orange-700 shadow">
                      {p.category}
                    </span>
                    <span className="absolute bottom-3 right-3 text-3xl drop-shadow-lg transition-transform duration-500 group-hover:rotate-12 group-hover:scale-125">
                      {p.emoji}
                    </span>
                  </div>
                ) : (
                  <div className="relative flex h-48 w-full items-center justify-center overflow-hidden bg-gradient-to-br from-yellow-100 via-orange-100 to-red-100">
                    <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-gradient-to-br from-yellow-200 to-red-200 opacity-70 transition-transform duration-500 group-hover:scale-150" />
                    <span className="relative text-7xl transition-transform duration-500 group-hover:rotate-12 group-hover:scale-110">
                      {p.emoji}
                    </span>
                    <span className="absolute left-3 top-3 rounded-full bg-white/90 px-2.5 py-1 text-xs font-bold text-orange-700 shadow">
                      {p.category}
                    </span>
                  </div>
                )}
                <div className="flex flex-1 flex-col p-5">
                <h3 className="relative text-xl font-black text-stone-900">{p.name}</h3>
                <p className="relative mt-1 min-h-10 flex-1 text-sm text-stone-600">{p.description}</p>
                <div className="relative mt-4 flex items-center justify-between">
                  <span className="text-2xl font-black text-red-600">{brl(Number(p.price))}</span>
                  <button
                    onClick={() => addToCart(p)}
                    className="btn-brand rounded-full px-5 py-2 text-sm font-bold"
                  >
                    + Adicionar
                  </button>
                </div>
                </div>
              </article>
            ))}
          </div>
        )}
      </section>

      {/* FOOTER */}
      <footer className="border-t border-orange-100 bg-white/60">
        <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-3 px-4 py-8 text-sm text-stone-600 md:flex-row">
          <p>© {new Date().getFullYear()} {store.name} · {store.address}</p>
          <div className="flex gap-4">
            <a
              className="font-semibold text-green-700 hover:underline"
              href={`https://wa.me/${store.whatsapp}`}
              target="_blank"
              rel="noreferrer"
            >
              WhatsApp
            </a>
            <Link href="/entregador/login" className="hover:underline">Área do entregador</Link>
            <Link href="/admin/login" className="hover:underline">Área administrativa</Link>
          </div>
        </div>
      </footer>

      {/* TOAST */}
      {toast && (
        <div className="animate-pop fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-stone-900 px-5 py-2.5 text-sm font-semibold text-white shadow-2xl">
          {toast}
        </div>
      )}

      {/* FLOATING CART (mobile) */}
      {cartCount > 0 && !cartOpen && !checkoutOpen && (
        <button
          onClick={() => setCartOpen(true)}
          className="btn-brand animate-pop fixed bottom-5 right-5 z-40 flex items-center gap-3 rounded-full px-5 py-3 font-bold md:hidden"
        >
          🛒 {cartCount} · {brl(total)}
        </button>
      )}

      {/* CART DRAWER */}
      {cartOpen && (
        <div className="fixed inset-0 z-50 flex justify-end">
          <div className="animate-fade-in absolute inset-0 bg-black/40" onClick={() => setCartOpen(false)} />
          <aside className="animate-slide-in-right relative flex h-full w-full max-w-md flex-col bg-white shadow-2xl">
            <div className="flex items-center justify-between border-b px-5 py-4">
              <h3 className="text-xl font-black">Seu carrinho</h3>
              <button onClick={() => setCartOpen(false)} className="rounded-full p-2 hover:bg-stone-100">✕</button>
            </div>
            <div className="flex-1 space-y-3 overflow-y-auto px-5 py-4">
              {cart.length === 0 && (
                <div className="py-16 text-center text-stone-500">
                  <div className="text-5xl">🫙</div>
                  <p className="mt-2">Seu carrinho está vazio.</p>
                </div>
              )}
              {cart.map((i) => (
                <div key={i.product.id} className="animate-fade-in flex items-center gap-3 rounded-2xl bg-orange-50 p-3">
                  {i.product.imageUrl ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={i.product.imageUrl} alt={i.product.name} className="h-14 w-14 shrink-0 rounded-xl object-cover" />
                  ) : (
                    <span className="text-3xl">{i.product.emoji}</span>
                  )}
                  <div className="flex-1">
                    <p className="font-bold">{i.product.name}</p>
                    <p className="text-sm text-stone-600">{brl(Number(i.product.price))}</p>
                  </div>
                  <div className="flex items-center gap-2">
                    <button onClick={() => changeQty(i.product.id, -1)} className="h-8 w-8 rounded-full bg-white font-black shadow">−</button>
                    <span className="w-5 text-center font-bold">{i.quantity}</span>
                    <button onClick={() => changeQty(i.product.id, 1)} className="h-8 w-8 rounded-full bg-red-600 font-black text-white shadow">+</button>
                  </div>
                </div>
              ))}
            </div>
            <div className="border-t px-5 py-4">
              <div className="flex justify-between text-sm text-stone-600"><span>Subtotal</span><span>{brl(subtotal)}</span></div>
              <div className="flex justify-between text-sm text-stone-600"><span>Entrega</span><span>{brl(cart.length ? store.deliveryFee : 0)}</span></div>
              {belowMinimum && (
                <p className="mt-1 text-xs font-semibold text-orange-600">
                  Pedido mínimo: {brl(store.minOrder)} (sem a taxa de entrega)
                </p>
              )}
              <div className="mt-1 flex justify-between text-lg font-black"><span>Total</span><span>{brl(total)}</span></div>
              <button
                disabled={cart.length === 0}
                onClick={() => {
                  setCartOpen(false);
                  setCheckoutOpen(true);
                }}
                className="btn-brand mt-4 w-full rounded-full py-3 font-bold disabled:opacity-40"
              >
                Continuar para entrega →
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* CHECKOUT MODAL */}
      {checkoutOpen && (
        <div className="fixed inset-0 z-50 flex items-end justify-center md:items-center">
          <div className="animate-fade-in absolute inset-0 bg-black/50" onClick={() => !submitting && setCheckoutOpen(false)} />
          <div className="animate-fade-in-up relative max-h-[95vh] w-full max-w-3xl overflow-y-auto rounded-t-3xl bg-white p-6 shadow-2xl md:rounded-3xl">
            {success ? (
              <div className="py-6 text-center">
                <div className="animate-pop text-7xl">✅</div>
                <h3 className="mt-3 text-2xl font-black">Pedido #{success.orderId} enviado!</h3>
                <p className="mt-2 text-stone-600">
                  Finalize a compra no WhatsApp da pizzaria. Assim que o ADM confirmar, sua localização é
                  liberada para o entregador.
                </p>
                <a
                  href={success.whatsappUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-6 inline-flex items-center gap-2 rounded-full bg-green-600 px-6 py-3 font-bold text-white shadow-lg shadow-green-200 transition hover:bg-green-700"
                >
                  💬 Abrir WhatsApp
                </a>
                <div>
                  <button
                    onClick={() => {
                      setSuccess(null);
                      setCheckoutOpen(false);
                    }}
                    className="mt-4 text-sm text-stone-500 underline"
                  >
                    Voltar ao cardápio
                  </button>
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between">
                  <h3 className="text-2xl font-black">Onde entregamos? 📍</h3>
                  <button onClick={() => setCheckoutOpen(false)} className="rounded-full p-2 hover:bg-stone-100">✕</button>
                </div>
                <div className="mt-4 grid gap-5 md:grid-cols-2">
                  <div className="space-y-3">
                    <button
                      type="button"
                      onClick={requestCurrentLocation}
                      disabled={locating}
                      className="flex w-full items-center justify-center gap-2 rounded-2xl border-2 border-dashed border-green-500 bg-green-50 px-4 py-3 font-bold text-green-800 transition hover:bg-green-100 disabled:opacity-60"
                    >
                      <span className={`relative inline-flex h-3 w-3 rounded-full bg-green-500 ${locating ? "pulse-ring text-green-500" : ""}`} />
                      {locating ? "Obtendo localização…" : "Usar minha localização atual"}
                    </button>
                    {locError && <p className="text-sm text-red-600">{locError}</p>}

                    <label className="block text-sm font-semibold">
                      Endereço completo
                      <div className="mt-1 flex gap-2">
                        <input
                          value={form.address}
                          onChange={(e) => setForm({ ...form, address: e.target.value })}
                          placeholder="Rua, número, bairro, cidade"
                          className="w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
                        />
                        <button
                          type="button"
                          onClick={searchAddress}
                          className="rounded-xl bg-stone-900 px-3 text-white transition hover:bg-stone-700"
                          title="Localizar no mapa"
                        >
                          🔍
                        </button>
                      </div>
                    </label>
                    <label className="block text-sm font-semibold">
                      Complemento / referência
                      <input
                        value={form.complement}
                        onChange={(e) => setForm({ ...form, complement: e.target.value })}
                        placeholder="Apto, bloco, portão…"
                        className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
                      />
                    </label>
                    <div className="grid grid-cols-2 gap-3">
                      <label className="block text-sm font-semibold">
                        Seu nome
                        <input
                          value={form.customerName}
                          onChange={(e) => setForm({ ...form, customerName: e.target.value })}
                          className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
                        />
                      </label>
                      <label className="block text-sm font-semibold">
                        WhatsApp
                        <input
                          value={form.customerPhone}
                          onChange={(e) => setForm({ ...form, customerPhone: e.target.value })}
                          placeholder="(11) 99999-9999"
                          className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
                        />
                      </label>
                    </div>
                    <label className="block text-sm font-semibold">
                      Pagamento
                      <select
                        value={form.paymentMethod}
                        onChange={(e) => setForm({ ...form, paymentMethod: e.target.value })}
                        className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500"
                      >
                        <option>Pix</option>
                        <option>Cartão na entrega</option>
                        <option>Dinheiro</option>
                      </select>
                    </label>
                    <label className="block text-sm font-semibold">
                      Observações
                      <textarea
                        value={form.notes}
                        onChange={(e) => setForm({ ...form, notes: e.target.value })}
                        rows={2}
                        placeholder="Sem cebola, borda recheada…"
                        className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
                      />
                    </label>
                  </div>

                  <div>
                    <p className="mb-2 text-sm text-stone-600">
                      {location
                        ? "📌 Localização marcada. Arraste o mapa ou toque para ajustar."
                        : "Toque no mapa para marcar o ponto exato da entrega."}
                    </p>
                    <LeafletMap
                      center={mapCenter}
                      zoom={location ? 16 : 13}
                      markers={mapMarkers}
                      onClick={(p) => setLocation(p)}
                      fitToMarkers={!!location}
                      className="h-64 w-full md:h-80"
                    />
                    {location && (
                      <p className="mt-1 text-xs text-stone-500">
                        {location.lat.toFixed(5)}, {location.lng.toFixed(5)}
                      </p>
                    )}
                    <div className="mt-4 rounded-2xl bg-orange-50 p-4">
                      <p className="text-sm font-bold">Resumo do pedido</p>
                      <ul className="mt-1 space-y-0.5 text-sm text-stone-700">
                        {cart.map((i) => (
                          <li key={i.product.id} className="flex justify-between">
                            <span>{i.quantity}x {i.product.name}</span>
                            <span>{brl(Number(i.product.price) * i.quantity)}</span>
                          </li>
                        ))}
                        <li className="flex justify-between text-stone-500"><span>Entrega</span><span>{brl(store.deliveryFee)}</span></li>
                      </ul>
                      <p className="mt-2 flex justify-between text-lg font-black"><span>Total</span><span>{brl(total)}</span></p>
                    </div>
                  </div>
                </div>

                {submitError && <p className="mt-3 text-sm font-semibold text-red-600">{submitError}</p>}
                {!store.isOpen && (
                  <p className="mt-3 rounded-xl bg-stone-100 p-3 text-center text-sm font-semibold text-stone-600">
                    😴 A pizzaria está fechada no momento. Volte mais tarde!
                  </p>
                )}
                <button
                  onClick={submitOrder}
                  disabled={submitting || cart.length === 0 || !store.isOpen || belowMinimum}
                  className="mt-5 flex w-full items-center justify-center gap-2 rounded-full bg-green-600 py-3.5 text-lg font-black text-white shadow-lg shadow-green-200 transition hover:bg-green-700 disabled:opacity-50"
                >
                  {submitting ? "Enviando…" : "💬 Comprar pelo WhatsApp"}
                </button>
                <p className="mt-2 text-center text-xs text-stone-500">
                  Você será direcionado ao WhatsApp da {store.name}
                  {store.whatsapp ? ` · ${formatPhone(store.whatsapp)}` : ""}
                </p>
                {cart.length === 0 && (
                  <p className="mt-2 text-center text-sm text-stone-500">Adicione itens do cardápio para continuar.</p>
                )}
              </>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
