"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState } from "react";
import LeafletMap, { type MapMarker } from "@/components/LeafletMap";
import { ORDER_STATUS_LABEL, STORE } from "@/lib/config";
import { googleMapsUrl, wazeUrl } from "@/lib/route";

type OrderItem = { productId: number; name: string; price: number; quantity: number };
type RouteOrder = {
  id: number;
  customerName: string;
  customerPhone: string;
  address: string;
  complement: string;
  lat: number;
  lng: number;
  items: OrderItem[];
  total: string;
  notes: string;
  paymentMethod: string;
  status: string;
  locationConfirmed: boolean;
  sequence: number;
  legKm: number;
};
type UnlocatedOrder = Omit<RouteOrder, "lat" | "lng" | "sequence" | "legKm"> & { lat: null; lng: null };

type RouteData = {
  start: { lat: number; lng: number };
  storeName?: string;
  route: RouteOrder[];
  unlocated: UnlocatedOrder[];
  totalKm: number;
  googleMapsRouteUrl: string;
  delivered: { id: number; customerName: string; total: string; updatedAt: string }[];
};

const brl = (v: number | string) =>
  Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

export default function DelivererPanel({ user }: { user: { id: number; name: string } }) {
  const router = useRouter();
  const [data, setData] = useState<RouteData | null>(null);
  const [loading, setLoading] = useState(true);
  const [myPos, setMyPos] = useState<{ lat: number; lng: number } | null>(null);
  const [msg, setMsg] = useState<string | null>(null);

  const load = useCallback(async () => {
    const r = await fetch("/api/orders");
    if (r.status === 401) {
      router.push("/entregador/login");
      return;
    }
    const d = await r.json();
    setData(d);
    setLoading(false);
  }, [router]);

  useEffect(() => {
    load();
    const t = setInterval(load, 15000);
    return () => clearInterval(t);
  }, [load]);

  useEffect(() => {
    if (!navigator.geolocation) return;
    const id = navigator.geolocation.watchPosition(
      (p) => setMyPos({ lat: p.coords.latitude, lng: p.coords.longitude }),
      () => {},
      { enableHighAccuracy: true, maximumAge: 10000 }
    );
    return () => navigator.geolocation.clearWatch(id);
  }, []);

  const flash = (t: string) => {
    setMsg(t);
    setTimeout(() => setMsg(null), 2200);
  };

  const action = async (id: number, act: "em_rota" | "entregue") => {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action: act }),
    });
    if (!res.ok) {
      const d = await res.json();
      return flash(d.error || "Erro");
    }
    flash(act === "entregue" ? "Entrega concluída! 🎉" : "Boa viagem! 🛵");
    load();
  };

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/entregador/login");
    router.refresh();
  };

  const markers = useMemo<MapMarker[]>(() => {
    if (!data) return [];
    const list: MapMarker[] = [
      { id: "store", lat: data.start.lat, lng: data.start.lng, label: "🍕", color: "#d62828", popup: `<b>${data.storeName || STORE.name}</b>` },
    ];
    data.route.forEach((o) =>
      list.push({
        id: o.id,
        lat: o.lat,
        lng: o.lng,
        label: String(o.sequence),
        color: o.status === "em_rota" ? "#7b2cbf" : "#2a6f97",
        popup: `<b>${o.sequence}º · Pedido #${o.id}</b><br/>${o.customerName}<br/>${o.address}<br/><b>${brl(o.total)}</b>`,
      })
    );
    if (myPos) list.push({ id: "me", lat: myPos.lat, lng: myPos.lng, label: "🛵", color: "#2f5d3a", popup: "Você está aqui" });
    return list;
  }, [data, myPos]);

  const polyline = useMemo(() => {
    if (!data) return [];
    return [data.start, ...data.route.map((o) => ({ lat: o.lat, lng: o.lng }))];
  }, [data]);

  return (
    <div className="min-h-screen bg-stone-100 pb-24">
      <header className="sticky top-0 z-30 bg-gradient-to-r from-purple-700 to-fuchsia-600 text-white shadow-lg">
        <div className="mx-auto flex max-w-5xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="animate-float text-3xl">🛵</span>
            <div>
              <p className="text-xs uppercase tracking-widest text-purple-200">Entregador</p>
              <p className="font-black leading-tight">{user.name}</p>
            </div>
          </div>
          <div className="flex items-center gap-2 text-sm">
            <button onClick={load} className="rounded-full border border-white/40 px-3 py-1.5 transition hover:bg-white/10">↻ Atualizar</button>
            <button onClick={logout} className="rounded-full bg-white/20 px-3 py-1.5 font-semibold transition hover:bg-white/30">Sair</button>
          </div>
        </div>
      </header>

      {msg && (
        <div className="animate-pop fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full bg-stone-900 px-5 py-2.5 text-sm font-semibold text-white shadow-2xl">
          {msg}
        </div>
      )}

      <main className="mx-auto max-w-5xl space-y-5 px-4 py-5">
        {loading || !data ? (
          <div className="space-y-3">
            <div className="h-24 animate-pulse rounded-3xl bg-white" />
            <div className="h-80 animate-pulse rounded-3xl bg-white" />
          </div>
        ) : (
          <>
            {/* Resumo */}
            <div className="animate-fade-in-up grid grid-cols-3 gap-3">
              <div className="rounded-2xl bg-white p-4 shadow-sm">
                <p className="text-3xl font-black text-purple-700">{data.route.length + data.unlocated.length}</p>
                <p className="text-xs font-semibold text-stone-500">entregas pendentes</p>
              </div>
              <div className="rounded-2xl bg-white p-4 shadow-sm">
                <p className="text-3xl font-black text-purple-700">{data.totalKm} km</p>
                <p className="text-xs font-semibold text-stone-500">rota otimizada</p>
              </div>
              <div className="rounded-2xl bg-white p-4 shadow-sm">
                <p className="text-3xl font-black text-purple-700">{data.delivered.length}</p>
                <p className="text-xs font-semibold text-stone-500">entregues recentes</p>
              </div>
            </div>

            {/* Mapa */}
            <div className="animate-fade-in-up delay-100 rounded-3xl bg-white p-4 shadow-sm">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-lg font-black">🗺️ Mapa da rota</h2>
                {data.route.length > 0 && (
                  <a
                    href={data.googleMapsRouteUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="rounded-full bg-emerald-600 px-4 py-1.5 text-sm font-bold text-white shadow transition hover:bg-emerald-500"
                  >
                    Abrir rota completa no Google Maps
                  </a>
                )}
              </div>
              <LeafletMap
                center={data.start}
                zoom={13}
                markers={markers}
                polyline={polyline}
                fitToMarkers={markers.length > 1}
                className="h-72 w-full md:h-96"
              />
              <p className="mt-2 text-xs text-stone-500">
                A ordem foi calculada automaticamente a partir da pizzaria, indo sempre para o ponto de entrega mais próximo do anterior.
              </p>
            </div>

            {/* Lista da rota */}
            <div className="space-y-3">
              <h2 className="text-lg font-black">📋 Sequência de entregas</h2>
              {data.route.length === 0 && data.unlocated.length === 0 && (
                <div className="animate-fade-in rounded-3xl bg-white p-10 text-center text-stone-500 shadow-sm">
                  <div className="animate-float text-5xl">😎</div>
                  <p className="mt-2 font-semibold">Nenhuma entrega no momento.</p>
                  <p className="text-sm">Assim que o ADM confirmar um pedido e atribuir a você, ele aparece aqui.</p>
                </div>
              )}
              {data.route.map((o, i) => (
                <div
                  key={o.id}
                  className="animate-fade-in-up card-hover relative overflow-hidden rounded-3xl bg-white p-5 shadow-sm"
                  style={{ animationDelay: `${i * 70}ms` }}
                >
                  <div className="absolute left-0 top-0 h-full w-1.5 bg-gradient-to-b from-purple-600 to-fuchsia-500" />
                  <div className="flex items-start gap-4">
                    <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-purple-600 text-xl font-black text-white shadow-lg shadow-purple-200">
                      {o.sequence}
                    </div>
                    <div className="flex-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <h3 className="text-lg font-black">Pedido #{o.id} · {brl(o.total)}</h3>
                        <span className={`rounded-full px-3 py-1 text-xs font-bold ${o.status === "em_rota" ? "bg-purple-100 text-purple-800" : "bg-blue-100 text-blue-800"}`}>
                          {ORDER_STATUS_LABEL[o.status]}
                        </span>
                      </div>
                      <p className="text-sm text-stone-500">
                        ➜ {o.legKm} km do ponto anterior{o.locationConfirmed ? " · ✅ localização confirmada pelo ADM" : ""}
                      </p>
                      <p className="mt-2 font-bold">👤 {o.customerName}</p>
                      <a href={`tel:${o.customerPhone}`} className="text-sm text-green-700 hover:underline">📞 {o.customerPhone}</a>
                      <p className="mt-1 text-sm text-stone-700">📍 {o.address}{o.complement ? ` — ${o.complement}` : ""}</p>
                      <p className="mt-1 text-xs text-stone-500">
                        {o.items.map((it) => `${it.quantity}x ${it.name}`).join(", ")} · 💳 {o.paymentMethod}
                      </p>
                      {o.notes && <p className="text-xs text-stone-500">📝 {o.notes}</p>}

                      <div className="mt-4 flex flex-wrap gap-2">
                        <a
                          href={wazeUrl(o)}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1.5 rounded-full bg-sky-500 px-4 py-2 text-sm font-bold text-white shadow transition hover:bg-sky-400"
                        >
                          🚗 Waze
                        </a>
                        <a
                          href={googleMapsUrl(o)}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1.5 rounded-full bg-emerald-600 px-4 py-2 text-sm font-bold text-white shadow transition hover:bg-emerald-500"
                        >
                          🗺️ Google Maps
                        </a>
                        <a
                          href={`https://wa.me/55${o.customerPhone.replace(/^55/, "")}?text=${encodeURIComponent(`Olá ${o.customerName}! Sou o entregador da ${data.storeName || STORE.name}, estou a caminho com seu pedido #${o.id} 🍕`)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-full bg-green-100 px-4 py-2 text-sm font-bold text-green-800 transition hover:bg-green-200"
                        >
                          💬 Avisar cliente
                        </a>
                        {o.status === "confirmado" ? (
                          <button onClick={() => action(o.id, "em_rota")} className="rounded-full bg-purple-600 px-4 py-2 text-sm font-bold text-white shadow transition hover:bg-purple-500">
                            🛵 Iniciar entrega
                          </button>
                        ) : (
                          <button onClick={() => action(o.id, "entregue")} className="btn-brand rounded-full px-4 py-2 text-sm font-bold">
                            ✅ Entregue
                          </button>
                        )}
                      </div>
                    </div>
                  </div>
                </div>
              ))}

              {data.unlocated.length > 0 && (
                <div className="animate-fade-in rounded-3xl border-2 border-dashed border-orange-300 bg-orange-50 p-5">
                  <h3 className="font-black text-orange-800">⚠️ Sem coordenadas (use o endereço)</h3>
                  {data.unlocated.map((o) => (
                    <div key={o.id} className="mt-3 rounded-2xl bg-white p-4">
                      <p className="font-bold">Pedido #{o.id} · {o.customerName} · {brl(o.total)}</p>
                      <p className="text-sm text-stone-700">📍 {o.address}{o.complement ? ` — ${o.complement}` : ""}</p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        <a
                          href={`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(o.address)}`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-full bg-emerald-600 px-4 py-1.5 text-sm font-bold text-white"
                        >
                          🗺️ Google Maps
                        </a>
                        <a
                          href={`https://waze.com/ul?q=${encodeURIComponent(o.address)}&navigate=yes`}
                          target="_blank"
                          rel="noreferrer"
                          className="rounded-full bg-sky-500 px-4 py-1.5 text-sm font-bold text-white"
                        >
                          🚗 Waze
                        </a>
                        {o.status === "confirmado" ? (
                          <button onClick={() => action(o.id, "em_rota")} className="rounded-full bg-purple-600 px-4 py-1.5 text-sm font-bold text-white">🛵 Iniciar</button>
                        ) : (
                          <button onClick={() => action(o.id, "entregue")} className="btn-brand rounded-full px-4 py-1.5 text-sm font-bold">✅ Entregue</button>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {data.delivered.length > 0 && (
              <div className="animate-fade-in rounded-3xl bg-white p-5 shadow-sm">
                <h2 className="text-lg font-black">✅ Entregas concluídas</h2>
                <ul className="mt-2 divide-y text-sm">
                  {data.delivered.map((d) => (
                    <li key={d.id} className="flex justify-between py-2">
                      <span>#{d.id} · {d.customerName}</span>
                      <span className="text-stone-500">{brl(d.total)} · {new Date(d.updatedAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" })}</span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </>
        )}
      </main>
    </div>
  );
}
