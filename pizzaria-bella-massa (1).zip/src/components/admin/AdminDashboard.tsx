"use client";

import { useRouter } from "next/navigation";
import { useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import LeafletMap, { type MapMarker } from "@/components/LeafletMap";
import ImageUploader from "@/components/admin/ImageUploader";
import { ORDER_STATUS_LABEL, STORE } from "@/lib/config";
import { googleMapsUrl, wazeUrl } from "@/lib/route";

type OrderItem = { productId: number; name: string; price: number; quantity: number };
type Order = {
  id: number;
  customerName: string;
  customerPhone: string;
  address: string;
  complement: string;
  lat: number | null;
  lng: number | null;
  items: OrderItem[];
  total: string;
  notes: string;
  paymentMethod: string;
  status: string;
  locationConfirmed: boolean;
  delivererId: number | null;
  createdAt: string;
};
type Product = {
  id: number;
  name: string;
  description: string;
  category: string;
  price: string;
  emoji: string;
  imageUrl: string | null;
  available: boolean;
};
type Deliverer = { id: number; name: string; phone: string; vehicle: string; active: boolean };
type Admin = { id: number; name: string; email: string; createdAt: string };

type Tab = "pedidos" | "mapa" | "produtos" | "entregadores" | "admins" | "config";

type StoreSettings = {
  whatsapp: string;
  storeName: string;
  storeAddress: string;
  storeLat: number;
  storeLng: number;
  deliveryFee: number;
  minOrder: number;
  isOpen: boolean;
};

/** Formata 5511999999999 → +55 (11) 99999-9999 */
function formatPhone(digits: string): string {
  const d = digits.replace(/\D/g, "");
  const m = d.match(/^55(\d{2})(\d{4,5})(\d{4})$/);
  if (m) return `+55 (${m[1]}) ${m[2]}-${m[3]}`;
  return d ? `+${d}` : "";
}

const brl = (v: number | string) =>
  Number(v).toLocaleString("pt-BR", { style: "currency", currency: "BRL" });

const STATUS_COLOR: Record<string, string> = {
  pendente: "bg-yellow-100 text-yellow-800",
  confirmado: "bg-blue-100 text-blue-800",
  em_rota: "bg-purple-100 text-purple-800",
  entregue: "bg-green-100 text-green-800",
  cancelado: "bg-stone-200 text-stone-600",
};
const STATUS_MARKER: Record<string, string> = {
  pendente: "#f4a261",
  confirmado: "#2a6f97",
  em_rota: "#7b2cbf",
  entregue: "#2f5d3a",
  cancelado: "#9a9a9a",
};

export default function AdminDashboard({ user }: { user: { id: number; name: string } }) {
  const router = useRouter();
  const [tab, setTab] = useState<Tab>("pedidos");
  const [orders, setOrders] = useState<Order[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [deliverers, setDeliverers] = useState<Deliverer[]>([]);
  const [adminsList, setAdminsList] = useState<Admin[]>([]);
  const [msg, setMsg] = useState<{ type: "ok" | "err"; text: string } | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>("ativos");
  const [cfg, setCfg] = useState<StoreSettings>({
    whatsapp: STORE.whatsapp,
    storeName: STORE.name,
    storeAddress: STORE.address,
    storeLat: STORE.lat,
    storeLng: STORE.lng,
    deliveryFee: STORE.deliveryFee,
    minOrder: 0,
    isOpen: true,
  });
  const [cfgForm, setCfgForm] = useState({
    whatsapp: "",
    storeName: "",
    storeAddress: "",
    storeLat: "",
    storeLng: "",
    deliveryFee: "",
    minOrder: "",
  });
  const [savingCfg, setSavingCfg] = useState(false);

  const applyCfg = (s: StoreSettings) => {
    setCfg(s);
    setCfgForm({
      whatsapp: s.whatsapp,
      storeName: s.storeName,
      storeAddress: s.storeAddress,
      storeLat: String(s.storeLat),
      storeLng: String(s.storeLng),
      deliveryFee: String(s.deliveryFee),
      minOrder: String(s.minOrder),
    });
  };

  const flash = (type: "ok" | "err", text: string) => {
    setMsg({ type, text });
    setTimeout(() => setMsg(null), 2500);
  };

  const loadAll = useCallback(async () => {
    const [o, p, d, a, s] = await Promise.all([
      fetch("/api/orders").then((r) => r.json()),
      fetch("/api/products?all=1").then((r) => r.json()),
      fetch("/api/deliverers").then((r) => r.json()),
      fetch("/api/admins").then((r) => r.json()),
      fetch("/api/settings").then((r) => r.json()),
    ]);
    setOrders(o.orders || []);
    setProducts(p.products || []);
    setDeliverers(d.deliverers || []);
    setAdminsList(a.admins || []);
    if (s.settings) applyCfg(s.settings);
  }, []);

  // ---------- Configurações da loja ----------
  const saveCfg = async (e: FormEvent) => {
    e.preventDefault();
    setSavingCfg(true);
    try {
      const res = await fetch("/api/settings", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          whatsapp: cfgForm.whatsapp,
          storeName: cfgForm.storeName,
          storeAddress: cfgForm.storeAddress,
          storeLat: Number(cfgForm.storeLat.replace(",", ".")),
          storeLng: Number(cfgForm.storeLng.replace(",", ".")),
          deliveryFee: Number(cfgForm.deliveryFee.replace(",", ".")),
          minOrder: Number(cfgForm.minOrder.replace(",", ".") || 0),
        }),
      });
      const data = await res.json();
      if (!res.ok) return flash("err", data.error || "Erro ao salvar");
      applyCfg(data.settings);
      flash("ok", "Configurações salvas! O botão Comprar já usa o novo WhatsApp.");
    } finally {
      setSavingCfg(false);
    }
  };
  const toggleOpen = async () => {
    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isOpen: !cfg.isOpen }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    applyCfg(data.settings);
    flash("ok", data.settings.isOpen ? "Pizzaria ABERTA para pedidos." : "Pizzaria FECHADA — clientes não conseguem comprar.");
  };
  const useStoreGps = () => {
    if (!navigator.geolocation) return flash("err", "Sem suporte a geolocalização.");
    navigator.geolocation.getCurrentPosition(
      (p) => setCfgForm((f) => ({ ...f, storeLat: p.coords.latitude.toFixed(6), storeLng: p.coords.longitude.toFixed(6) })),
      () => flash("err", "Não foi possível obter a localização.")
    );
  };

  useEffect(() => {
    loadAll();
    const t = setInterval(() => {
      fetch("/api/orders")
        .then((r) => r.json())
        .then((d) => setOrders(d.orders || []));
    }, 15000);
    return () => clearInterval(t);
  }, [loadAll]);

  const logout = async () => {
    await fetch("/api/auth/logout", { method: "POST" });
    router.push("/admin/login");
    router.refresh();
  };

  // ---------- Pedidos ----------
  const orderAction = async (id: number, action: string, extra: Record<string, unknown> = {}) => {
    const res = await fetch(`/api/orders/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ action, ...extra }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setOrders((os) => os.map((o) => (o.id === id ? data.order : o)));
    if (action === "confirmar") {
      flash(
        "ok",
        data.order.locationConfirmed
          ? "Venda confirmada e localização do cliente confirmada para entrega!"
          : "Venda confirmada (cliente sem coordenadas — use o endereço)."
      );
    } else flash("ok", "Pedido atualizado.");
  };

  const filteredOrders = useMemo(() => {
    if (statusFilter === "ativos") return orders.filter((o) => !["entregue", "cancelado"].includes(o.status));
    if (statusFilter === "todos") return orders;
    return orders.filter((o) => o.status === statusFilter);
  }, [orders, statusFilter]);

  const stats = useMemo(() => {
    const today = new Date().toDateString();
    const todayOrders = orders.filter((o) => new Date(o.createdAt).toDateString() === today);
    return {
      pendentes: orders.filter((o) => o.status === "pendente").length,
      emRota: orders.filter((o) => o.status === "em_rota").length,
      hoje: todayOrders.length,
      faturamento: todayOrders
        .filter((o) => o.status !== "cancelado")
        .reduce((s, o) => s + Number(o.total), 0),
    };
  }, [orders]);

  const mapMarkers = useMemo<MapMarker[]>(() => {
    const list: MapMarker[] = [
      { id: "store", lat: cfg.storeLat, lng: cfg.storeLng, label: "🍕", color: "#d62828", popup: `<b>${cfg.storeName}</b><br/>${cfg.storeAddress}` },
    ];
    orders
      .filter((o) => o.lat !== null && o.lng !== null && !["entregue", "cancelado"].includes(o.status))
      .forEach((o) => {
        const d = deliverers.find((x) => x.id === o.delivererId);
        list.push({
          id: o.id,
          lat: o.lat as number,
          lng: o.lng as number,
          label: String(o.id),
          color: STATUS_MARKER[o.status] || "#d62828",
          popup: `<b>Pedido #${o.id}</b> — ${ORDER_STATUS_LABEL[o.status]}<br/>${o.customerName} · ${o.customerPhone}<br/>${o.address}<br/>${d ? `🛵 ${d.name}` : "Sem entregador"}<br/><b>${brl(o.total)}</b>`,
        });
      });
    return list;
  }, [orders, deliverers, cfg.storeLat, cfg.storeLng, cfg.storeName, cfg.storeAddress]);

  // ---------- Produtos ----------
  const [newProduct, setNewProduct] = useState({ name: "", description: "", category: "Pizzas Tradicionais", price: "", emoji: "🍕", imageUrl: "" });
  const createProduct = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/products", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...newProduct, price: Number(newProduct.price.replace(",", ".")) }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setProducts((p) => [...p, data.product]);
    setNewProduct({ name: "", description: "", category: newProduct.category, price: "", emoji: "🍕", imageUrl: "" });
    flash("ok", "Produto adicionado!");
  };
  const [editingImageId, setEditingImageId] = useState<number | null>(null);
  const updateProductImage = async (p: Product, imageUrl: string) => {
    const res = await fetch(`/api/products/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ imageUrl: imageUrl || null }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setProducts((ps) => ps.map((x) => (x.id === p.id ? data.product : x)));
    flash("ok", imageUrl ? "Imagem do produto atualizada!" : "Imagem removida.");
  };
  const toggleAvailable = async (p: Product) => {
    const res = await fetch(`/api/products/${p.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ available: !p.available }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setProducts((ps) => ps.map((x) => (x.id === p.id ? data.product : x)));
    flash("ok", data.product.available ? "Produto disponível novamente." : "Produto marcado como esgotado.");
  };
  const deleteProduct = async (p: Product) => {
    if (!confirm(`Excluir "${p.name}" do cardápio?`)) return;
    const res = await fetch(`/api/products/${p.id}`, { method: "DELETE" });
    if (!res.ok) return flash("err", "Erro ao excluir");
    setProducts((ps) => ps.filter((x) => x.id !== p.id));
    flash("ok", "Produto excluído.");
  };
  const deleteSoldOut = async () => {
    const soldOut = products.filter((p) => !p.available);
    if (soldOut.length === 0) return flash("err", "Nenhum produto esgotado.");
    if (!confirm(`Excluir ${soldOut.length} produto(s) esgotado(s)?`)) return;
    await Promise.all(soldOut.map((p) => fetch(`/api/products/${p.id}`, { method: "DELETE" })));
    setProducts((ps) => ps.filter((p) => p.available));
    flash("ok", "Produtos esgotados excluídos.");
  };

  // ---------- Entregadores ----------
  const [newDeliverer, setNewDeliverer] = useState({ name: "", phone: "", vehicle: "Moto", password: "" });
  const createDeliverer = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/deliverers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newDeliverer),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setDeliverers((d) => [...d, data.deliverer]);
    setNewDeliverer({ name: "", phone: "", vehicle: "Moto", password: "" });
    flash("ok", "Entregador cadastrado!");
  };
  const toggleDeliverer = async (d: Deliverer) => {
    const res = await fetch(`/api/deliverers/${d.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ active: !d.active }),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setDeliverers((ds) => ds.map((x) => (x.id === d.id ? data.deliverer : x)));
  };
  const deleteDeliverer = async (d: Deliverer) => {
    if (!confirm(`Excluir entregador ${d.name}?`)) return;
    const res = await fetch(`/api/deliverers/${d.id}`, { method: "DELETE" });
    if (!res.ok) return flash("err", "Erro ao excluir");
    setDeliverers((ds) => ds.filter((x) => x.id !== d.id));
    flash("ok", "Entregador removido.");
  };

  // ---------- Admins ----------
  const [newAdmin, setNewAdmin] = useState({ name: "", email: "", password: "" });
  const createAdmin = async (e: FormEvent) => {
    e.preventDefault();
    const res = await fetch("/api/admins", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newAdmin),
    });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setAdminsList((a) => [...a, data.admin]);
    setNewAdmin({ name: "", email: "", password: "" });
    flash("ok", "Novo administrador cadastrado!");
  };
  const deleteAdmin = async (a: Admin) => {
    if (!confirm(`Remover administrador ${a.name}?`)) return;
    const res = await fetch(`/api/admins/${a.id}`, { method: "DELETE" });
    const data = await res.json();
    if (!res.ok) return flash("err", data.error || "Erro");
    setAdminsList((as) => as.filter((x) => x.id !== a.id));
    flash("ok", "Administrador removido.");
  };

  const tabs: { key: Tab; label: string; icon: string; badge?: number }[] = [
    { key: "pedidos", label: "Pedidos", icon: "🧾", badge: stats.pendentes },
    { key: "mapa", label: "Mapa de clientes", icon: "🗺️" },
    { key: "produtos", label: "Produtos", icon: "🍕" },
    { key: "entregadores", label: "Entregadores", icon: "🛵" },
    { key: "admins", label: "Administradores", icon: "🛡️" },
    { key: "config", label: "Configurações", icon: "⚙️" },
  ];

  const inputCls =
    "mt-1 w-full rounded-xl border border-stone-300 px-3 py-2 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100";

  return (
    <div className="min-h-screen bg-stone-100">
      <header className="sticky top-0 z-30 bg-stone-900 text-white shadow-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🛡️</span>
            <div>
              <p className="text-xs uppercase tracking-widest text-stone-400">Painel ADM</p>
              <p className="font-black leading-tight">{cfg.storeName}</p>
            </div>
          </div>
          <div className="flex items-center gap-3 text-sm">
            <button
              onClick={toggleOpen}
              title="Abrir/fechar a loja para pedidos"
              className={`flex items-center gap-1.5 rounded-full px-3 py-1.5 font-bold transition ${
                cfg.isOpen ? "bg-green-500 text-white hover:bg-green-400" : "bg-stone-700 text-stone-200 hover:bg-stone-600"
              }`}
            >
              <span className={`h-2 w-2 rounded-full ${cfg.isOpen ? "bg-white animate-pulse" : "bg-stone-400"}`} />
              {cfg.isOpen ? "Aberta" : "Fechada"}
            </button>
            <span className="hidden text-stone-300 sm:inline">Olá, <b className="text-white">{user.name}</b></span>
            <a href="/" className="rounded-full border border-stone-600 px-3 py-1.5 transition hover:bg-stone-800">Ver site</a>
            <button onClick={logout} className="rounded-full bg-red-600 px-3 py-1.5 font-semibold transition hover:bg-red-500">Sair</button>
          </div>
        </div>
      </header>

      {/* Stats */}
      <div className="mx-auto grid max-w-7xl gap-3 px-4 pt-6 sm:grid-cols-2 lg:grid-cols-4">
        {[
          ["⏳", "Aguardando confirmação", stats.pendentes, "from-yellow-400 to-orange-500"],
          ["🛵", "Em rota", stats.emRota, "from-purple-500 to-fuchsia-500"],
          ["📦", "Pedidos hoje", stats.hoje, "from-sky-500 to-blue-600"],
          ["💰", "Faturamento hoje", brl(stats.faturamento), "from-emerald-500 to-green-600"],
        ].map(([icon, label, val, grad], i) => (
          <div
            key={label as string}
            className={`animate-fade-in-up card-hover rounded-2xl bg-gradient-to-br ${grad} p-4 text-white shadow-lg`}
            style={{ animationDelay: `${i * 80}ms` }}
          >
            <div className="flex items-center justify-between">
              <span className="text-2xl">{icon}</span>
              <span className="text-3xl font-black">{val}</span>
            </div>
            <p className="mt-1 text-sm font-semibold text-white/90">{label}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="mx-auto mt-6 max-w-7xl px-4">
        <div className="flex gap-2 overflow-x-auto pb-2">
          {tabs.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`relative flex shrink-0 items-center gap-2 rounded-full px-4 py-2 text-sm font-bold transition-all ${
                tab === t.key ? "bg-red-600 text-white shadow-lg shadow-red-200" : "bg-white text-stone-700 hover:bg-red-50"
              }`}
            >
              <span>{t.icon}</span> {t.label}
              {t.badge ? (
                <span className="ml-1 rounded-full bg-yellow-400 px-2 text-xs font-black text-red-900">{t.badge}</span>
              ) : null}
            </button>
          ))}
        </div>
      </div>

      {msg && (
        <div
          className={`animate-pop fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-full px-5 py-2.5 text-sm font-semibold text-white shadow-2xl ${
            msg.type === "ok" ? "bg-green-600" : "bg-red-600"
          }`}
        >
          {msg.text}
        </div>
      )}

      <main className="mx-auto max-w-7xl px-4 py-6">
        {/* ---------------- PEDIDOS ---------------- */}
        {tab === "pedidos" && (
          <div className="animate-fade-in space-y-4">
            <div className="flex flex-wrap gap-2">
              {[
                ["ativos", "Ativos"],
                ["pendente", "Pendentes"],
                ["confirmado", "Confirmados"],
                ["em_rota", "Em rota"],
                ["entregue", "Entregues"],
                ["cancelado", "Cancelados"],
                ["todos", "Todos"],
              ].map(([k, l]) => (
                <button
                  key={k}
                  onClick={() => setStatusFilter(k)}
                  className={`rounded-full px-3 py-1 text-xs font-bold transition ${
                    statusFilter === k ? "bg-stone-900 text-white" : "bg-white text-stone-600 hover:bg-stone-200"
                  }`}
                >
                  {l}
                </button>
              ))}
            </div>

            {filteredOrders.length === 0 && (
              <div className="rounded-3xl bg-white p-12 text-center text-stone-500 shadow-sm">
                <div className="text-5xl">🍽️</div>
                <p className="mt-2">Nenhum pedido nesta categoria.</p>
              </div>
            )}

            <div className="grid gap-4 lg:grid-cols-2">
              {filteredOrders.map((o, i) => {
                const deliverer = deliverers.find((d) => d.id === o.delivererId);
                const hasLoc = o.lat !== null && o.lng !== null;
                return (
                  <div
                    key={o.id}
                    className="animate-fade-in-up card-hover rounded-3xl bg-white p-5 shadow-sm"
                    style={{ animationDelay: `${(i % 8) * 60}ms` }}
                  >
                    <div className="flex flex-wrap items-start justify-between gap-2">
                      <div>
                        <p className="text-xs text-stone-500">
                          {new Date(o.createdAt).toLocaleString("pt-BR")}
                        </p>
                        <h3 className="text-xl font-black">
                          Pedido #{o.id} · <span className="text-red-600">{brl(o.total)}</span>
                        </h3>
                      </div>
                      <span className={`rounded-full px-3 py-1 text-xs font-bold ${STATUS_COLOR[o.status]}`}>
                        {ORDER_STATUS_LABEL[o.status]}
                      </span>
                    </div>

                    <div className="mt-3 grid gap-2 text-sm sm:grid-cols-2">
                      <div>
                        <p className="font-bold">👤 {o.customerName}</p>
                        <a className="text-green-700 hover:underline" href={`https://wa.me/55${o.customerPhone.replace(/^55/, "")}`} target="_blank" rel="noreferrer">
                          📞 {o.customerPhone}
                        </a>
                        <p className="mt-1 text-stone-700">📍 {o.address}{o.complement ? ` — ${o.complement}` : ""}</p>
                        <p className="mt-1 text-xs">
                          {hasLoc ? (
                            <span className={o.locationConfirmed ? "font-bold text-green-700" : "text-stone-500"}>
                              {o.locationConfirmed ? "✅ Localização confirmada para entrega" : "🗺️ Coordenadas recebidas (aguardando confirmação)"}
                            </span>
                          ) : (
                            <span className="text-orange-600">⚠️ Cliente não enviou coordenadas</span>
                          )}
                        </p>
                        <p className="text-xs text-stone-500">💳 {o.paymentMethod}</p>
                        {o.notes && <p className="text-xs text-stone-500">📝 {o.notes}</p>}
                      </div>
                      <ul className="rounded-2xl bg-orange-50 p-3 text-stone-700">
                        {o.items.map((it, idx) => (
                          <li key={idx} className="flex justify-between">
                            <span>{it.quantity}x {it.name}</span>
                            <span>{brl(it.price * it.quantity)}</span>
                          </li>
                        ))}
                      </ul>
                    </div>

                    <div className="mt-4 flex flex-wrap items-center gap-2">
                      <select
                        value={o.delivererId ?? ""}
                        onChange={(e) => orderAction(o.id, "atribuir", { delivererId: e.target.value || null })}
                        className="rounded-xl border border-stone-300 px-2 py-1.5 text-sm"
                        disabled={["entregue", "cancelado"].includes(o.status)}
                      >
                        <option value="">🛵 Sem entregador</option>
                        {deliverers.filter((d) => d.active).map((d) => (
                          <option key={d.id} value={d.id}>{d.name} ({d.vehicle})</option>
                        ))}
                      </select>
                      {deliverer && <span className="text-xs text-stone-500">Atribuído a <b>{deliverer.name}</b></span>}
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      {o.status === "pendente" && (
                        <button onClick={() => orderAction(o.id, "confirmar")} className="btn-brand rounded-full px-4 py-1.5 text-sm font-bold">
                          ✅ Confirmar venda
                        </button>
                      )}
                      {o.status === "confirmado" && (
                        <button onClick={() => orderAction(o.id, "em_rota")} className="rounded-full bg-purple-600 px-4 py-1.5 text-sm font-bold text-white hover:bg-purple-500">
                          🛵 Saiu para entrega
                        </button>
                      )}
                      {o.status === "em_rota" && (
                        <button onClick={() => orderAction(o.id, "entregue")} className="rounded-full bg-green-600 px-4 py-1.5 text-sm font-bold text-white hover:bg-green-500">
                          📦 Marcar entregue
                        </button>
                      )}
                      {!["entregue", "cancelado"].includes(o.status) && (
                        <button onClick={() => orderAction(o.id, "cancelar")} className="rounded-full bg-stone-200 px-4 py-1.5 text-sm font-bold text-stone-700 hover:bg-stone-300">
                          Cancelar
                        </button>
                      )}
                      {["entregue", "cancelado"].includes(o.status) && (
                        <button onClick={() => orderAction(o.id, "reabrir")} className="rounded-full bg-stone-200 px-4 py-1.5 text-sm font-bold text-stone-700 hover:bg-stone-300">
                          Reabrir
                        </button>
                      )}
                      {hasLoc && (
                        <>
                          <a href={wazeUrl({ lat: o.lat as number, lng: o.lng as number })} target="_blank" rel="noreferrer" className="rounded-full bg-sky-100 px-3 py-1.5 text-sm font-bold text-sky-800 hover:bg-sky-200">Waze</a>
                          <a href={googleMapsUrl({ lat: o.lat as number, lng: o.lng as number })} target="_blank" rel="noreferrer" className="rounded-full bg-emerald-100 px-3 py-1.5 text-sm font-bold text-emerald-800 hover:bg-emerald-200">Google Maps</a>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ---------------- MAPA ---------------- */}
        {tab === "mapa" && (
          <div className="animate-fade-in rounded-3xl bg-white p-5 shadow-sm">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
              <h2 className="text-xl font-black">Localização dos clientes (pedidos ativos)</h2>
              <div className="flex flex-wrap gap-3 text-xs">
                {Object.entries(STATUS_MARKER)
                  .filter(([k]) => !["entregue", "cancelado"].includes(k))
                  .map(([k, c]) => (
                    <span key={k} className="flex items-center gap-1">
                      <span className="inline-block h-3 w-3 rounded-full" style={{ background: c }} />
                      {ORDER_STATUS_LABEL[k]}
                    </span>
                  ))}
                <span className="flex items-center gap-1"><span className="inline-block h-3 w-3 rounded-full bg-red-600" />Pizzaria</span>
              </div>
            </div>
            <LeafletMap
              center={{ lat: cfg.storeLat, lng: cfg.storeLng }}
              zoom={13}
              markers={mapMarkers}
              fitToMarkers={mapMarkers.length > 1}
              className="h-[65vh] w-full"
            />
            <p className="mt-2 text-xs text-stone-500">
              Clique em um marcador para ver os detalhes do pedido. O número no marcador é o número do pedido.
            </p>
          </div>
        )}

        {/* ---------------- PRODUTOS ---------------- */}
        {tab === "produtos" && (
          <div className="animate-fade-in grid gap-6 lg:grid-cols-3">
            <form onSubmit={createProduct} className="rounded-3xl bg-white p-5 shadow-sm lg:col-span-1">
              <h2 className="text-xl font-black">➕ Novo produto</h2>
              <label className="mt-3 block text-sm font-semibold">Nome
                <input required value={newProduct.name} onChange={(e) => setNewProduct({ ...newProduct, name: e.target.value })} className={inputCls} />
              </label>
              <label className="mt-3 block text-sm font-semibold">Descrição
                <textarea rows={2} value={newProduct.description} onChange={(e) => setNewProduct({ ...newProduct, description: e.target.value })} className={inputCls} />
              </label>
              <div className="mt-3 grid grid-cols-3 gap-2">
                <label className="col-span-2 block text-sm font-semibold">Preço (R$)
                  <input required inputMode="decimal" value={newProduct.price} onChange={(e) => setNewProduct({ ...newProduct, price: e.target.value })} placeholder="49,90" className={inputCls} />
                </label>
                <label className="block text-sm font-semibold">Emoji
                  <input value={newProduct.emoji} onChange={(e) => setNewProduct({ ...newProduct, emoji: e.target.value })} className={inputCls} />
                </label>
              </div>
              <label className="mt-3 block text-sm font-semibold">Categoria
                <input list="cats" value={newProduct.category} onChange={(e) => setNewProduct({ ...newProduct, category: e.target.value })} className={inputCls} />
                <datalist id="cats">
                  {Array.from(new Set(products.map((p) => p.category))).map((c) => <option key={c} value={c} />)}
                </datalist>
              </label>
              <div className="mt-3">
                <p className="text-sm font-semibold">Foto do produto (opcional)</p>
                <div className="mt-1">
                  <ImageUploader
                    value={newProduct.imageUrl}
                    onChange={(url) => setNewProduct((np) => ({ ...np, imageUrl: url }))}
                    onError={(m) => flash("err", m)}
                  />
                </div>
              </div>
              <button className="btn-brand mt-4 w-full rounded-full py-2.5 font-bold">Adicionar ao cardápio</button>
            </form>

            <div className="lg:col-span-2">
              <div className="mb-3 flex items-center justify-between">
                <h2 className="text-xl font-black">Cardápio ({products.length})</h2>
                <button onClick={deleteSoldOut} className="rounded-full bg-stone-900 px-4 py-1.5 text-sm font-bold text-white hover:bg-stone-700">
                  🗑️ Excluir todos esgotados
                </button>
              </div>
              <div className="grid gap-3 sm:grid-cols-2">
                {products.map((p, i) => (
                  <div
                    key={p.id}
                    className={`animate-fade-in-up card-hover rounded-2xl bg-white p-4 shadow-sm ${!p.available ? "opacity-70 grayscale" : ""}`}
                    style={{ animationDelay: `${(i % 10) * 40}ms` }}
                  >
                    <div className="flex items-start gap-3">
                      {p.imageUrl ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={p.imageUrl} alt={p.name} className="h-16 w-16 shrink-0 rounded-xl object-cover shadow" />
                      ) : (
                        <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-xl bg-orange-50 text-4xl">{p.emoji}</span>
                      )}
                      <div className="flex-1">
                        <div className="flex items-center justify-between gap-2">
                          <h3 className="font-black">{p.name}</h3>
                          <span className="font-black text-red-600">{brl(p.price)}</span>
                        </div>
                        <p className="text-xs text-stone-500">{p.category}</p>
                        <p className="mt-1 text-sm text-stone-600">{p.description}</p>
                      </div>
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${p.available ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
                        {p.available ? "Disponível" : "Esgotado"}
                      </span>
                      <button onClick={() => toggleAvailable(p)} className="rounded-full bg-stone-100 px-3 py-1 text-xs font-bold hover:bg-stone-200">
                        {p.available ? "Marcar esgotado" : "Repor estoque"}
                      </button>
                      <button
                        onClick={() => setEditingImageId(editingImageId === p.id ? null : p.id)}
                        className="rounded-full bg-sky-50 px-3 py-1 text-xs font-bold text-sky-700 hover:bg-sky-100"
                      >
                        📷 {p.imageUrl ? "Alterar foto" : "Adicionar foto"}
                      </button>
                      <button onClick={() => deleteProduct(p)} className="rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-red-700 hover:bg-red-100">
                        Excluir
                      </button>
                    </div>
                    {editingImageId === p.id && (
                      <div className="animate-fade-in mt-3 rounded-2xl bg-stone-50 p-3">
                        <ImageUploader
                          compact
                          value={p.imageUrl ?? ""}
                          onChange={(url) => {
                            updateProductImage(p, url);
                            if (url) setEditingImageId(null);
                          }}
                          onError={(m) => flash("err", m)}
                        />
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- ENTREGADORES ---------------- */}
        {tab === "entregadores" && (
          <div className="animate-fade-in grid gap-6 lg:grid-cols-3">
            <form onSubmit={createDeliverer} className="rounded-3xl bg-white p-5 shadow-sm">
              <h2 className="text-xl font-black">🛵 Cadastrar entregador</h2>
              <label className="mt-3 block text-sm font-semibold">Nome
                <input required value={newDeliverer.name} onChange={(e) => setNewDeliverer({ ...newDeliverer, name: e.target.value })} className={inputCls} />
              </label>
              <label className="mt-3 block text-sm font-semibold">Telefone (login)
                <input required value={newDeliverer.phone} onChange={(e) => setNewDeliverer({ ...newDeliverer, phone: e.target.value })} placeholder="11999999999" className={inputCls} />
              </label>
              <label className="mt-3 block text-sm font-semibold">Veículo
                <select value={newDeliverer.vehicle} onChange={(e) => setNewDeliverer({ ...newDeliverer, vehicle: e.target.value })} className={inputCls}>
                  <option>Moto</option><option>Bicicleta</option><option>Carro</option><option>A pé</option>
                </select>
              </label>
              <label className="mt-3 block text-sm font-semibold">Senha de acesso
                <input required type="text" value={newDeliverer.password} onChange={(e) => setNewDeliverer({ ...newDeliverer, password: e.target.value })} className={inputCls} />
              </label>
              <button className="btn-brand mt-4 w-full rounded-full py-2.5 font-bold">Cadastrar</button>
            </form>
            <div className="lg:col-span-2">
              <h2 className="mb-3 text-xl font-black">Equipe ({deliverers.length})</h2>
              {deliverers.length === 0 && <p className="rounded-3xl bg-white p-8 text-center text-stone-500">Nenhum entregador cadastrado ainda.</p>}
              <div className="grid gap-3 sm:grid-cols-2">
                {deliverers.map((d, i) => {
                  const active = orders.filter((o) => o.delivererId === d.id && ["confirmado", "em_rota"].includes(o.status)).length;
                  return (
                    <div key={d.id} className="animate-fade-in-up card-hover rounded-2xl bg-white p-4 shadow-sm" style={{ animationDelay: `${i * 50}ms` }}>
                      <div className="flex items-center gap-3">
                        <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-purple-500 to-fuchsia-500 text-2xl">
                          {d.vehicle === "Bicicleta" ? "🚴" : d.vehicle === "Carro" ? "🚗" : d.vehicle === "A pé" ? "🚶" : "🛵"}
                        </div>
                        <div className="flex-1">
                          <h3 className="font-black">{d.name}</h3>
                          <p className="text-sm text-stone-600">📞 {d.phone} · {d.vehicle}</p>
                        </div>
                        <span className={`rounded-full px-2.5 py-0.5 text-xs font-bold ${d.active ? "bg-green-100 text-green-800" : "bg-stone-200 text-stone-600"}`}>
                          {d.active ? "Ativo" : "Inativo"}
                        </span>
                      </div>
                      <p className="mt-2 text-xs text-stone-500">{active} entrega(s) em andamento</p>
                      <div className="mt-3 flex gap-2">
                        <button onClick={() => toggleDeliverer(d)} className="rounded-full bg-stone-100 px-3 py-1 text-xs font-bold hover:bg-stone-200">
                          {d.active ? "Desativar" : "Ativar"}
                        </button>
                        <button onClick={() => deleteDeliverer(d)} className="rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-red-700 hover:bg-red-100">Excluir</button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- ADMINS ---------------- */}
        {tab === "admins" && (
          <div className="animate-fade-in grid gap-6 lg:grid-cols-3">
            <form onSubmit={createAdmin} className="rounded-3xl bg-white p-5 shadow-sm">
              <h2 className="text-xl font-black">🛡️ Novo administrador</h2>
              <label className="mt-3 block text-sm font-semibold">Nome
                <input required value={newAdmin.name} onChange={(e) => setNewAdmin({ ...newAdmin, name: e.target.value })} className={inputCls} />
              </label>
              <label className="mt-3 block text-sm font-semibold">E-mail (login)
                <input required type="email" value={newAdmin.email} onChange={(e) => setNewAdmin({ ...newAdmin, email: e.target.value })} className={inputCls} />
              </label>
              <label className="mt-3 block text-sm font-semibold">Senha (mín. 6)
                <input required type="text" minLength={6} value={newAdmin.password} onChange={(e) => setNewAdmin({ ...newAdmin, password: e.target.value })} className={inputCls} />
              </label>
              <button className="btn-brand mt-4 w-full rounded-full py-2.5 font-bold">Cadastrar administrador</button>
            </form>
            <div className="lg:col-span-2">
              <h2 className="mb-3 text-xl font-black">Administradores ({adminsList.length})</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                {adminsList.map((a, i) => (
                  <div key={a.id} className="animate-fade-in-up card-hover rounded-2xl bg-white p-4 shadow-sm" style={{ animationDelay: `${i * 50}ms` }}>
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-stone-700 to-stone-900 text-xl text-white">
                        {a.name.charAt(0).toUpperCase()}
                      </div>
                      <div className="flex-1">
                        <h3 className="font-black">{a.name} {a.id === user.id && <span className="text-xs font-normal text-stone-500">(você)</span>}</h3>
                        <p className="text-sm text-stone-600">{a.email}</p>
                      </div>
                    </div>
                    <p className="mt-2 text-xs text-stone-500">Desde {new Date(a.createdAt).toLocaleDateString("pt-BR")}</p>
                    {a.id !== user.id && (
                      <button onClick={() => deleteAdmin(a)} className="mt-3 rounded-full bg-red-50 px-3 py-1 text-xs font-bold text-red-700 hover:bg-red-100">Remover</button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ---------------- CONFIGURAÇÕES ---------------- */}
        {tab === "config" && (
          <div className="animate-fade-in grid gap-6 lg:grid-cols-3">
            <form onSubmit={saveCfg} className="space-y-5 rounded-3xl bg-white p-5 shadow-sm lg:col-span-2">
              <div className="rounded-2xl border-2 border-green-200 bg-green-50 p-4">
                <h2 className="flex items-center gap-2 text-xl font-black text-green-900">
                  💬 WhatsApp da empresa
                </h2>
                <p className="mt-1 text-sm text-green-800">
                  Quando o cliente clicar em <b>“Comprar pelo WhatsApp”</b>, ele será direcionado para este número
                  com o pedido completo já preenchido.
                </p>
                <label className="mt-3 block text-sm font-semibold text-green-900">
                  Número com DDD
                  <input
                    required
                    inputMode="tel"
                    value={cfgForm.whatsapp}
                    onChange={(e) => setCfgForm({ ...cfgForm, whatsapp: e.target.value })}
                    placeholder="(11) 99999-9999"
                    className="mt-1 w-full rounded-xl border border-green-300 bg-white px-3 py-2.5 text-lg font-bold outline-none focus:border-green-600 focus:ring-2 focus:ring-green-100"
                  />
                </label>
                <p className="mt-1 text-xs text-green-800">
                  Pode digitar com ou sem o 55. Ex.: <code>11999999999</code> ou <code>5511999999999</code>.
                  {cfgForm.whatsapp && (
                    <> · Será salvo como <b>{formatPhone(cfgForm.whatsapp.replace(/\D/g, "").length <= 11 ? `55${cfgForm.whatsapp.replace(/\D/g, "")}` : cfgForm.whatsapp)}</b></>
                  )}
                </p>
                {cfg.whatsapp && (
                  <a
                    href={`https://wa.me/${cfg.whatsapp}?text=${encodeURIComponent("Teste do site da pizzaria ✅")}`}
                    target="_blank"
                    rel="noreferrer"
                    className="mt-3 inline-flex items-center gap-1.5 rounded-full bg-green-600 px-4 py-1.5 text-sm font-bold text-white hover:bg-green-500"
                  >
                    Testar número atual ({formatPhone(cfg.whatsapp)})
                  </a>
                )}
              </div>

              <div>
                <h3 className="font-black">🏪 Dados da pizzaria</h3>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="block text-sm font-semibold">Nome
                    <input required value={cfgForm.storeName} onChange={(e) => setCfgForm({ ...cfgForm, storeName: e.target.value })} className={inputCls} />
                  </label>
                  <label className="block text-sm font-semibold">Endereço
                    <input value={cfgForm.storeAddress} onChange={(e) => setCfgForm({ ...cfgForm, storeAddress: e.target.value })} className={inputCls} />
                  </label>
                </div>
              </div>

              <div>
                <div className="flex items-center justify-between">
                  <h3 className="font-black">📍 Localização da pizzaria</h3>
                  <button type="button" onClick={useStoreGps} className="rounded-full bg-stone-100 px-3 py-1 text-xs font-bold hover:bg-stone-200">
                    Usar minha posição atual
                  </button>
                </div>
                <p className="text-xs text-stone-500">Ponto de partida das rotas dos entregadores. Clique no mapa para ajustar.</p>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="block text-sm font-semibold">Latitude
                    <input required value={cfgForm.storeLat} onChange={(e) => setCfgForm({ ...cfgForm, storeLat: e.target.value })} className={inputCls} />
                  </label>
                  <label className="block text-sm font-semibold">Longitude
                    <input required value={cfgForm.storeLng} onChange={(e) => setCfgForm({ ...cfgForm, storeLng: e.target.value })} className={inputCls} />
                  </label>
                </div>
                <div className="mt-3">
                  <LeafletMap
                    center={{
                      lat: Number(cfgForm.storeLat.replace(",", ".")) || cfg.storeLat,
                      lng: Number(cfgForm.storeLng.replace(",", ".")) || cfg.storeLng,
                    }}
                    zoom={15}
                    markers={[
                      {
                        id: "store",
                        lat: Number(cfgForm.storeLat.replace(",", ".")) || cfg.storeLat,
                        lng: Number(cfgForm.storeLng.replace(",", ".")) || cfg.storeLng,
                        label: "🍕",
                        color: "#d62828",
                      },
                    ]}
                    onClick={(p) => setCfgForm((f) => ({ ...f, storeLat: p.lat.toFixed(6), storeLng: p.lng.toFixed(6) }))}
                    className="h-56 w-full"
                  />
                </div>
              </div>

              <div>
                <h3 className="font-black">💰 Entrega</h3>
                <div className="mt-2 grid gap-3 sm:grid-cols-2">
                  <label className="block text-sm font-semibold">Taxa de entrega (R$)
                    <input required inputMode="decimal" value={cfgForm.deliveryFee} onChange={(e) => setCfgForm({ ...cfgForm, deliveryFee: e.target.value })} className={inputCls} />
                  </label>
                  <label className="block text-sm font-semibold">Pedido mínimo (R$) — 0 para nenhum
                    <input inputMode="decimal" value={cfgForm.minOrder} onChange={(e) => setCfgForm({ ...cfgForm, minOrder: e.target.value })} className={inputCls} />
                  </label>
                </div>
              </div>

              <button disabled={savingCfg} className="btn-brand w-full rounded-full py-3 font-bold disabled:opacity-60">
                {savingCfg ? "Salvando…" : "💾 Salvar configurações"}
              </button>
            </form>

            <div className="space-y-4">
              <div className="rounded-3xl bg-white p-5 shadow-sm">
                <h3 className="font-black">🚦 Status da loja</h3>
                <p className="mt-1 text-sm text-stone-600">
                  Quando fechada, o site avisa os clientes e o botão de compra fica desativado.
                </p>
                <button
                  onClick={toggleOpen}
                  className={`mt-3 w-full rounded-full py-3 font-black text-white transition ${
                    cfg.isOpen ? "bg-stone-800 hover:bg-stone-700" : "bg-green-600 hover:bg-green-500"
                  }`}
                >
                  {cfg.isOpen ? "😴 Fechar pizzaria" : "🍕 Abrir pizzaria"}
                </button>
              </div>

              <div className="rounded-3xl bg-gradient-to-br from-green-600 to-emerald-700 p-5 text-white shadow-lg">
                <p className="text-xs uppercase tracking-widest text-green-100">Fluxo de compra</p>
                <ol className="mt-2 space-y-2 text-sm">
                  <li className="flex gap-2"><span className="font-black">1.</span> Cliente monta o pedido e informa a localização.</li>
                  <li className="flex gap-2"><span className="font-black">2.</span> Clica em <b>Comprar</b> → pedido salvo e WhatsApp da empresa aberto com a mensagem pronta.</li>
                  <li className="flex gap-2"><span className="font-black">3.</span> Você confirma a venda no painel → localização do cliente liberada ao entregador.</li>
                </ol>
                <p className="mt-3 rounded-xl bg-white/15 p-2 text-center text-sm font-bold">
                  Recebendo em: {cfg.whatsapp ? formatPhone(cfg.whatsapp) : "não configurado"}
                </p>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}
