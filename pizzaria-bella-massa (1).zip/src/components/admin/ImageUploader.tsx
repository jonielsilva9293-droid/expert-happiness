"use client";

import { useRef, useState } from "react";

type Props = {
  value: string; // URL atual ("" = sem imagem)
  onChange: (url: string) => void;
  onError?: (msg: string) => void;
  compact?: boolean;
};

const DEMO_IMAGES = [
  "/images/products/margherita.jpg",
  "/images/products/calabresa.jpg",
  "/images/products/portuguesa.jpg",
  "/images/products/quatro-queijos.jpg",
  "/images/products/frango-catupiry.jpg",
  "/images/products/pepperoni.jpg",
  "/images/products/chocolate-morango.jpg",
  "/images/products/banana-canela.jpg",
  "/images/products/refrigerante.jpg",
  "/images/products/suco.jpg",
];

/** Redimensiona a imagem no navegador (máx. 900px) e converte para JPEG para reduzir o upload. */
async function compressImage(file: File): Promise<Blob> {
  if (file.type === "image/gif") return file;
  const bitmap = await createImageBitmap(file).catch(() => null);
  if (!bitmap) return file;
  const MAX = 900;
  const scale = Math.min(1, MAX / Math.max(bitmap.width, bitmap.height));
  const w = Math.round(bitmap.width * scale);
  const h = Math.round(bitmap.height * scale);
  const canvas = document.createElement("canvas");
  canvas.width = w;
  canvas.height = h;
  const ctx = canvas.getContext("2d");
  if (!ctx) return file;
  ctx.drawImage(bitmap, 0, 0, w, h);
  const blob = await new Promise<Blob | null>((res) => canvas.toBlob(res, "image/jpeg", 0.85));
  return blob ?? file;
}

export default function ImageUploader({ value, onChange, onError, compact = false }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [showDemo, setShowDemo] = useState(false);
  const [urlMode, setUrlMode] = useState(false);
  const [urlDraft, setUrlDraft] = useState("");

  const upload = async (file: File) => {
    if (!file.type.startsWith("image/")) {
      onError?.("Selecione um arquivo de imagem.");
      return;
    }
    setUploading(true);
    setProgress(15);
    try {
      const blob = await compressImage(file);
      setProgress(45);
      const fd = new FormData();
      fd.append("file", new File([blob], file.name.replace(/\.\w+$/, ".jpg"), { type: blob.type || file.type }));
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Falha no upload");
      setProgress(100);
      onChange(data.url);
    } catch (e) {
      onError?.(e instanceof Error ? e.message : "Erro ao enviar imagem");
    } finally {
      setTimeout(() => {
        setUploading(false);
        setProgress(0);
      }, 400);
    }
  };

  const onDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) upload(file);
  };

  return (
    <div className="space-y-2">
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={onDrop}
        onClick={() => !uploading && inputRef.current?.click()}
        className={`group relative flex cursor-pointer items-center justify-center overflow-hidden rounded-2xl border-2 border-dashed transition ${
          value ? "border-transparent" : "border-stone-300 bg-stone-50 hover:border-red-400 hover:bg-red-50"
        } ${compact ? "h-28" : "h-40"}`}
      >
        {value ? (
          <>
            {/* eslint-disable-next-line @next/next/no-img-element */}
            <img src={value} alt="Pré-visualização" className="h-full w-full object-cover transition group-hover:scale-105" />
            <div className="absolute inset-0 flex items-center justify-center bg-black/0 text-sm font-bold text-white opacity-0 transition group-hover:bg-black/40 group-hover:opacity-100">
              📷 Trocar imagem
            </div>
          </>
        ) : (
          <div className="text-center text-sm text-stone-500">
            <div className="text-3xl">📷</div>
            <p className="font-semibold">Clique ou arraste uma imagem</p>
            <p className="text-xs">JPG, PNG ou WEBP · até 4 MB</p>
          </div>
        )}
        {uploading && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-white/80">
            <div className="h-2 w-2/3 overflow-hidden rounded-full bg-stone-200">
              <div className="h-full bg-red-600 transition-all duration-300" style={{ width: `${progress}%` }} />
            </div>
            <p className="mt-2 text-xs font-semibold text-stone-600">Enviando…</p>
          </div>
        )}
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) upload(f);
            e.target.value = "";
          }}
        />
      </div>

      <div className="flex flex-wrap gap-2 text-xs">
        <button type="button" onClick={() => setShowDemo((s) => !s)} className="rounded-full bg-stone-100 px-3 py-1 font-bold hover:bg-stone-200">
          🖼️ Usar imagem de demonstração
        </button>
        <button type="button" onClick={() => setUrlMode((s) => !s)} className="rounded-full bg-stone-100 px-3 py-1 font-bold hover:bg-stone-200">
          🔗 Colar URL
        </button>
        {value && (
          <button type="button" onClick={() => onChange("")} className="rounded-full bg-red-50 px-3 py-1 font-bold text-red-700 hover:bg-red-100">
            ✕ Remover imagem
          </button>
        )}
      </div>

      {showDemo && (
        <div className="animate-fade-in grid grid-cols-5 gap-2">
          {DEMO_IMAGES.map((src) => (
            <button
              key={src}
              type="button"
              onClick={() => {
                onChange(src);
                setShowDemo(false);
              }}
              className={`overflow-hidden rounded-xl border-2 transition hover:scale-105 ${value === src ? "border-red-600" : "border-transparent"}`}
            >
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={src} alt="" className="aspect-square w-full object-cover" />
            </button>
          ))}
        </div>
      )}

      {urlMode && (
        <div className="animate-fade-in flex gap-2">
          <input
            value={urlDraft}
            onChange={(e) => setUrlDraft(e.target.value)}
            placeholder="https://exemplo.com/imagem.jpg"
            className="w-full rounded-xl border border-stone-300 px-3 py-1.5 text-sm outline-none focus:border-red-500"
          />
          <button
            type="button"
            onClick={() => {
              if (urlDraft.trim()) onChange(urlDraft.trim());
              setUrlDraft("");
              setUrlMode(false);
            }}
            className="rounded-xl bg-stone-900 px-3 text-sm font-bold text-white"
          >
            OK
          </button>
        </div>
      )}
    </div>
  );
}
