"use client";

import { useEffect, useRef, useState } from "react";

export type MapMarker = {
  id: string | number;
  lat: number;
  lng: number;
  label?: string;
  color?: string;
  popup?: string;
};

type Props = {
  center: { lat: number; lng: number };
  zoom?: number;
  markers?: MapMarker[];
  polyline?: { lat: number; lng: number }[];
  onClick?: (p: { lat: number; lng: number }) => void;
  fitToMarkers?: boolean;
  className?: string;
};

/* eslint-disable @typescript-eslint/no-explicit-any */
declare global {
  interface Window {
    L?: any;
    __leafletLoading?: Promise<void>;
  }
}

const LEAFLET_CSS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.css";
const LEAFLET_JS = "https://unpkg.com/leaflet@1.9.4/dist/leaflet.js";

function loadLeaflet(): Promise<void> {
  if (typeof window === "undefined") return Promise.resolve();
  if (window.L) return Promise.resolve();
  if (window.__leafletLoading) return window.__leafletLoading;

  window.__leafletLoading = new Promise<void>((resolve, reject) => {
    if (!document.querySelector(`link[href="${LEAFLET_CSS}"]`)) {
      const link = document.createElement("link");
      link.rel = "stylesheet";
      link.href = LEAFLET_CSS;
      document.head.appendChild(link);
    }
    const script = document.createElement("script");
    script.src = LEAFLET_JS;
    script.async = true;
    script.onload = () => resolve();
    script.onerror = () => reject(new Error("Falha ao carregar o mapa"));
    document.head.appendChild(script);
  });
  return window.__leafletLoading;
}

export default function LeafletMap({
  center,
  zoom = 13,
  markers = [],
  polyline,
  onClick,
  fitToMarkers = false,
  className = "h-80 w-full",
}: Props) {
  const containerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<any>(null);
  const layerRef = useRef<any>(null);
  const onClickRef = useRef(onClick);
  onClickRef.current = onClick;
  const [ready, setReady] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Inicializa o mapa
  useEffect(() => {
    let cancelled = false;
    loadLeaflet()
      .then(() => {
        if (cancelled || !containerRef.current || mapRef.current) return;
        const L = window.L;
        const map = L.map(containerRef.current, { zoomControl: true }).setView(
          [center.lat, center.lng],
          zoom
        );
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
          maxZoom: 19,
          attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
        }).addTo(map);
        map.on("click", (e: any) => {
          onClickRef.current?.({ lat: e.latlng.lat, lng: e.latlng.lng });
        });
        layerRef.current = L.layerGroup().addTo(map);
        mapRef.current = map;
        setReady(true);
        setTimeout(() => map.invalidateSize(), 200);
      })
      .catch(() => setError("Não foi possível carregar o mapa."));
    return () => {
      cancelled = true;
      if (mapRef.current) {
        mapRef.current.remove();
        mapRef.current = null;
        layerRef.current = null;
      }
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Atualiza marcadores e linhas
  useEffect(() => {
    if (!ready) return;
    const L = window.L;
    const map = mapRef.current;
    const layer = layerRef.current;
    if (!L || !map || !layer) return;

    layer.clearLayers();
    const bounds: any[] = [];
    markers.forEach((m) => {
      const icon = L.divIcon({
        className: "",
        html: `<div class="bm-marker" style="background:${m.color || "#d62828"}"><span>${m.label ?? "📍"}</span></div>`,
        iconSize: [34, 34],
        iconAnchor: [17, 34],
        popupAnchor: [0, -30],
      });
      const marker = L.marker([m.lat, m.lng], { icon });
      if (m.popup) marker.bindPopup(m.popup);
      marker.addTo(layer);
      bounds.push([m.lat, m.lng]);
    });
    if (polyline && polyline.length > 1) {
      L.polyline(
        polyline.map((p) => [p.lat, p.lng]),
        { color: "#d62828", weight: 4, opacity: 0.8, dashArray: "8 10" }
      ).addTo(layer);
    }
    if (fitToMarkers && bounds.length > 1) {
      map.fitBounds(bounds, { padding: [40, 40], maxZoom: 16 });
    } else {
      map.setView([center.lat, center.lng], fitToMarkers ? 15 : map.getZoom());
    }
    setTimeout(() => map.invalidateSize(), 100);
  }, [ready, markers, polyline, center.lat, center.lng, fitToMarkers]);

  return (
    <div
      className={`relative overflow-hidden rounded-2xl border border-stone-200 bg-stone-100 ${className}`}
    >
      <div ref={containerRef} className="absolute inset-0 z-0" />
      {!ready && !error && (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-stone-500">
          <span className="animate-pulse">Carregando mapa…</span>
        </div>
      )}
      {error && (
        <div className="absolute inset-0 flex items-center justify-center text-sm text-red-600">{error}</div>
      )}
    </div>
  );
}
