"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useState, type FormEvent } from "react";

type Props = {
  role: "admin" | "deliverer";
  title: string;
  subtitle: string;
  identifierLabel: string;
  identifierPlaceholder: string;
  redirectTo: string;
  icon: string;
};

export default function LoginForm({
  role,
  title,
  subtitle,
  identifierLabel,
  identifierPlaceholder,
  redirectTo,
  icon,
}: Props) {
  const router = useRouter();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ role, identifier, password }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Falha no login");
      router.push(redirectTo);
      router.refresh();
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erro inesperado");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="checker flex min-h-screen items-center justify-center px-4">
      <div className="animate-fade-in-up w-full max-w-md rounded-3xl bg-white p-8 shadow-2xl shadow-red-100">
        <div className="animate-float mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-gradient-to-br from-yellow-300 to-red-500 text-4xl shadow-lg">
          {icon}
        </div>
        <h1 className="mt-5 text-center text-2xl font-black">{title}</h1>
        <p className="text-center text-sm text-stone-600">{subtitle}</p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          <label className="block text-sm font-semibold">
            {identifierLabel}
            <input
              value={identifier}
              onChange={(e) => setIdentifier(e.target.value)}
              placeholder={identifierPlaceholder}
              autoComplete="username"
              className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2.5 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
              required
            />
          </label>
          <label className="block text-sm font-semibold">
            Senha
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              autoComplete="current-password"
              className="mt-1 w-full rounded-xl border border-stone-300 px-3 py-2.5 outline-none focus:border-red-500 focus:ring-2 focus:ring-red-100"
              required
            />
          </label>
          {error && <p className="animate-pop text-sm font-semibold text-red-600">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="btn-brand w-full rounded-full py-3 font-bold disabled:opacity-60"
          >
            {loading ? "Entrando…" : "Entrar"}
          </button>
        </form>

        {role === "admin" && (
          <p className="mt-4 rounded-xl bg-orange-50 p-3 text-center text-xs text-stone-600">
            Acesso inicial: <b>admin@bellamassa.com</b>
          </p>
        )}

        <div className="mt-6 flex justify-between text-sm text-stone-500">
          <Link href="/" className="hover:underline">← Voltar ao site</Link>
          <Link href={role === "admin" ? "/entregador/login" : "/admin/login"} className="hover:underline">
            {role === "admin" ? "Sou entregador" : "Sou administrador"}
          </Link>
        </div>
      </div>
    </div>
  );
}
