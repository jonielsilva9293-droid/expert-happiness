import { defineConfig } from "drizzle-kit";

// Configuração usada para aplicar o schema no banco de PRODUÇÃO (ex.: Neon).
// Uso:  DATABASE_URL="postgresql://..." npx drizzle-kit push --config drizzle.prod.config.ts
const url = process.env.DATABASE_URL;
if (!url) {
  throw new Error("Defina DATABASE_URL antes de rodar o drizzle-kit em produção.");
}

export default defineConfig({
  dialect: "postgresql",
  schema: "./src/db/schema.ts",
  dbCredentials: { url },
});
