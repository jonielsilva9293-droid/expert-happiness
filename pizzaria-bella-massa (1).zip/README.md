# 🍕 Bella Massa Pizzaria

Site de pizzaria completo (Next.js + PostgreSQL) com área do cliente, painel do ADM e área do entregador.

- **Cliente:** `/` — cardápio, localização, pedido pelo WhatsApp
- **ADM:** `/admin/login` — pedidos, mapa de clientes, produtos (com upload de fotos), entregadores e administradores
- **Entregador:** `/entregador/login` — rota otimizada, Waze / Google Maps

Login inicial do ADM: `admin@bellamassa.com` / `J4590n23@`

---

## 🚀 Hospedagem gratuita (Vercel + Neon) — só pelo navegador

> O app **cria as tabelas do banco automaticamente** no primeiro acesso. Não é preciso instalar nada no computador.

### 1. Banco de dados — Neon (grátis)
1. Crie uma conta em <https://neon.tech> e clique em **New Project** (região: `South America (São Paulo)` se disponível).
2. Copie a **Connection string** (algo como `postgresql://usuario:senha@ep-xxx.aws.neon.tech/neondb?sslmode=require`).

### 2. Código — GitHub (sem git)
1. Baixe o projeto (`pizzaria-bella-massa.zip`) e descompacte.
2. Em <https://github.com/new> crie um repositório (ex.: `pizzaria`), marque **Public** ou **Private**.
3. Clique em **uploading an existing file**, arraste **todo o conteúdo da pasta** descompactada e clique em **Commit changes**.

### 3. Site — Vercel (grátis)
1. Crie uma conta em <https://vercel.com> usando o GitHub e clique em **Add New → Project**, escolha o repositório.
2. Em **Environment Variables** adicione:

| Nome | Valor |
|---|---|
| `DATABASE_URL` | URL do Neon |
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | ex.: `5511999999999` (DDI+DDD+número, só dígitos) |
| `NEXT_PUBLIC_STORE_LAT` | latitude da pizzaria, ex.: `-23.55052` |
| `NEXT_PUBLIC_STORE_LNG` | longitude da pizzaria, ex.: `-46.633308` |

3. Clique em **Deploy**. Em ~2 minutos você recebe uma URL do tipo `https://pizzaria.vercel.app`.

O ADM e os produtos de demonstração são criados automaticamente no primeiro acesso.

### 4. Depois do deploy (recomendado)
- Entre em `/admin/login`, crie **um novo administrador** com sua senha, saia, entre com ele e **remova o ADM padrão**.
- Para usar um domínio próprio (ex.: `pizzariabellamassa.com.br`), vá em *Settings → Domains* na Vercel.

---

## 🛠️ Rodando localmente
```bash
npm install
# edite o .env com sua DATABASE_URL local
npx drizzle-kit push
npm run dev
```
